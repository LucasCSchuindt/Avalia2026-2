# Relatório — Agente 1: Arquiteto Serverless, Cloudflare D1 e Segurança Discord OAuth2

Projeto: `P26-2B-1768-7598-7D8E-716E` — escopo de escrita: `functions/**`, `lib/**`, `migrations/**`.

## O que revisei

- `lib/jogo.js`, `lib/placar.js`, `lib/session.js`
- Todas as rotas em `functions/api/**` (incluindo `auth/discord.js` + `auth/discord/callback.js`)
- `migrations/0001_init.sql`, `migrations/0002_batalha_naval.sql`, `wrangler.jsonc`
- `tests/teste-api.mjs` (para entender o shim de D1 e os contratos testados)

### Itens conferidos e que JÁ estavam corretos (não mexi)

- **Validação da frota (limites 10x10):** `validarFrota` exige os 5 navios oficiais, cada um uma vez, coordenadas inteiras, orientação `H`/`V`, todas as células dentro da malha e sem sobreposição.
- **Matriz do oponente oculta:** `frota_servidor` nunca sai do D1; `visaoPublica` filtra campos; `fire` devolve só `resultado` (`água` / `acerto` / `navio afundado`), sem `navioId` nem células.
- **Sessão:** cookie `discord_session` `HttpOnly; Secure; SameSite=Lax`, HMAC-SHA256 via `crypto.subtle.verify` (comparação em tempo constante), expiração no payload.
- **OAuth2:** `state` aleatório em cookie `HttpOnly` com `Path=/api/auth`, comparado no callback; `redirect_uri` idêntico no authorize e na troca do token; escopo `identify`; cookie de state apagado no fim.
- **SQL:** 100% `prepare().bind()`, nenhuma interpolação.
- **Runtime Cloudflare:** só APIs Web (`fetch`, `crypto.subtle`, `crypto.randomUUID`, `btoa/atob`, `TextEncoder`); imports relativos para `../lib` são empacotados pelo build das Pages Functions; `functions/api/auth/discord.js` e `functions/api/auth/discord/callback.js` coexistem sem conflito (rotas `/api/auth/discord` e `/api/auth/discord/callback`); `INSERT ... RETURNING *` dentro de `batch` e `meta.changes` são suportados pelo D1.
- **Códigos HTTP:** 400 (JSON/coordenada/frota), 401 (sem sessão ou cookie forjado), 403 (partida de outro jogador, checado antes de revelar o status), 404, 409 (tiro repetido, partida encerrada, conflito de versão), 503 (sem D1).
- Disparo com trava otimista por `versao` (já impedia dois tiros simultâneos na mesma jogada).

## Problemas encontrados (linhas referentes ao código ORIGINAL)

1. **Condição de corrida no `POST /api/game/new` — placar contado em dobro** (`functions/api/game/new.js:33-36`).
   O batch fazia `UPDATE ... status='abandonada' WHERE status='ativa'` e, **incondicionalmente**, gravava uma derrota no placar. Se a partida fosse encerrada por outra requisição entre o `SELECT` e o `batch` (ex.: o último tiro dando vitória, ou outro `new`/`surrender` concorrente), o UPDATE alterava 0 linhas mas a derrota era registrada mesmo assim → a mesma partida contava vitória **e** derrota, ou derrota duas vezes.

2. **Condição de corrida no `POST /api/game/new` — duas partidas ativas** (`functions/api/game/new.js:38-42` + esquema).
   Dois `new` simultâneos criavam duas partidas `ativa` para o mesmo jogador (nada no banco impedia). Reproduzi forçando a intercalação: antes `201/201` com 2 partidas ativas.

3. **Encerramento e placar fora da mesma transação** (`functions/api/game/fire.js:66-73` e `functions/api/game/surrender.js:98-103`).
   O UPDATE que encerra a partida e o UPSERT do placar eram dois comandos separados; se o segundo falhasse (erro transitório do D1), a partida ficava encerrada sem o placar atualizado — o requisito "placar geral atualizado ao término" podia ser violado silenciosamente. (A lógica de corrida em si estava correta porque o placar só rodava se `changes === 1`.)

4. **Exceções não tratadas** (todas as rotas): uma falha do D1 gerava a página de erro padrão do runtime (não-JSON), quebrando o `res.json()` do frontend.

5. **Menores:** `lerJson` (`lib/session.js:104-105`) lia o corpo inteiro antes de checar o limite e media caracteres em vez de bytes; `voltar()` no callback OAuth (`functions/api/auth/discord/callback.js:116-124`) não tinha `Cache-Control: no-store` num redirect que mexe em cookie.

## O que alterei e por quê

| Arquivo | Mudança |
|---|---|
| `lib/placar.js` | `registrarFimDePartida(db, user, venceu, tiros, { seAlterou })`: o UPSERT virou `INSERT ... SELECT ... WHERE ? = 0 OR changes() = 1 ON CONFLICT ...`. Com `seAlterou: true`, a linha do placar só é gravada se o comando anterior do mesmo `batch` (o UPDATE com trava) alterou exatamente 1 linha. Sem a opção, o comportamento é o mesmo de antes. |
| `functions/api/game/fire.js` | No fim do confronto, `UPDATE` (com trava de versão) + placar vão num único `env.DB.batch` (transação). Se o confronto continua, segue um `run()` simples como antes. Checagem de `meta.changes` mantida → 409 `conflito`. |
| `functions/api/game/surrender.js` | Mesma ideia: encerramento + placar no mesmo `batch`, placar condicionado a `changes() = 1`. |
| `functions/api/game/new.js` | Derrota por abandono condicionada a `changes() = 1`; `batch` envolto em try/catch: violação do índice único → **409 `conflito`** (antes criaria partida duplicada). |
| `migrations/0003_partida_ativa_unica.sql` (novo) | Fecha duplicatas antigas (mantém a ativa mais recente) e cria `UNIQUE INDEX idx_batalha_partidas_uma_ativa ON batalha_partidas(user_id) WHERE status = 'ativa'`. |
| `lib/session.js` | `ensureSchema` replica a migração 0003 (limpeza + índice único). `lerJson` recusa cedo via `Content-Length` e mede o tamanho em bytes. |
| `functions/api/_middleware.js` (novo) | Middleware de `/api/*`: exceção não tratada → JSON `500 {ok:false,error:"erro_interno",message}` sem stack trace (o erro vai para `console.error`, visível nos logs da Cloudflare). |
| `functions/api/auth/discord/callback.js` | `Cache-Control: no-store` nos redirects de erro. |

**Contratos JSON:** nenhum contrato existente mudou. A única novidade observável é que `POST /api/game/new` pode responder **409** `{ok:false,error:"conflito",message}` quando dois pedidos de nova partida colidem — mesmo formato de erro já usado nas outras rotas, e o frontend já mostra `message` em qualquer erro não-401.

**Deploy:** é preciso rodar `npx.cmd wrangler d1 migrations apply DB --remote` de novo para aplicar a `0003` (de qualquer forma, `ensureSchema` cria o índice sozinho na primeira requisição).

## Testes

- `node tests/teste-api.mjs` (Node 22): **51 aprovados, 0 reprovados** (100%).
- Teste extra ad-hoc (fora do projeto, `/tmp`), com o mesmo shim de D1 e batches serializados como no D1 real, forçando os dois `SELECT` a acontecerem antes dos `batch`:
  - 2× `POST /api/game/new` concorrentes com partida ativa → `201` / `409`, **1** partida ativa, derrota contada **1** vez (antes: `201/201`, 2 partidas ativas).
  - 2× `POST /api/game/surrender` concorrentes → `200` / `409`, derrota contada 1 vez.
  - Middleware: exceção → `500` JSON.

## Observações honestas / limites

- A proteção usa a função `changes()` do SQLite dentro de `db.batch()`. O D1 roda o batch como uma transação sequencial numa única conexão SQLite, então isso funciona. Mas não testei contra um D1 real (só contra o shim `node:sqlite`); vale um teste rápido após o deploy (jogar uma partida até o fim e conferir `/api/placar`).
- `redirect_uri` é derivado da origem da requisição: funciona no domínio de produção cadastrado no Discord, mas deploys de preview (`<hash>.<projeto>.pages.dev`) vão falhar no login porque essa URL não está cadastrada. Isso é esperado e não mexi.
- O ranking público expõe `user_id` do Discord dos jogadores; é um dado público do Discord e o próprio cabeçalho já mostra, então mantive.
- O shim do teste não serializa batches concorrentes (`BEGIN` dentro de `BEGIN` dá erro). Isso não afeta a bateria oficial, que é sequencial, mas fica como sugestão ao Agente 3.

---

## Rodada 2 — correções pedidas pelo Agente 3

### 1. Método HTTP errado (D1, severidade baixa)

**Problema:** rotas só-POST (`/api/game/new`, `/api/game/fire`, `/api/game/surrender`, `/api/auth/logout`) não tinham handler para GET. No Pages, a requisição caía nos arquivos estáticos e voltava `index.html` com 200. Nas outras rotas, um método errado dava 405 sem JSON.

**Correção:**
- `lib/session.js`: novo helper `metodoNaoPermitido(...permitidos)` → `405 {ok:false, error:"method_not_allowed", message}` com cabeçalho `Allow` e `Cache-Control: no-store`.
- Cada rota de API agora exporta `export async function onRequest() { return metodoNaoPermitido("GET"|"POST"); }`:
  - só-POST: `game/new.js`, `game/fire.js`, `game/surrender.js`, `auth/logout.js` (`Allow: POST`);
  - só-GET: `me.js`, `placar.js`, `game/state.js`, `auth/discord.js`, `auth/discord/callback.js` (`Allow: GET`).
- `status.js` já tinha o próprio `onRequest` com 405 JSON e `Allow: GET` (testado). Mantive como estava.

**Precedência confirmada:** a documentação oficial (developers.cloudflare.com/pages/functions/api-reference/) diz: *"The `onRequest` method will be called unless a more specific `onRequestVerb` method is exported."* Ou seja, `onRequestGet`/`onRequestPost` continuam atendendo o método certo e o `onRequest` só pega os outros métodos. Nenhum contrato existente mudou.

**Observação:** HEAD em rota só-GET também cai no `onRequest` e recebe 405. É aceitável para uma API JSON.

### 2. CHECK de status no `ensureSchema` (informativo)

`lib/session.js`: o `CREATE TABLE IF NOT EXISTS batalha_partidas` do `ensureSchema` agora tem `CHECK (status IN ('ativa', 'vitoria', 'derrota', 'abandonada'))`, igual à migração 0002. Conferi num SQLite em memória: inserir `status='xx'` falha com `CHECK constraint failed`.

### Testes

- `node tests/teste-api.mjs`: **67 aprovados, 0 reprovados** (100%). O aviso da seção 6 sobre rotas sem `onRequest` de fallback não aparece mais.
- **Caso de teste do 405:** não acrescentei nada em `tests/teste-api.mjs`, porque `tests/` está fora do meu escopo de escrita e o Agente 3 trabalha nesse arquivo. Verifiquei com um script à parte (`/tmp/a1/m405.mjs`), usando a mesma lógica de despacho do harness (o handler do verbo vem antes do `onRequest`). Resultado: as 9 rotas respondem 405, `Content-Type: application/json`, `Allow` correto e `error: "method_not_allowed"` para o método errado, e todas continuam exportando o handler do método certo. Sugestão ao Agente 3, por exemplo: `igual((await chamar(rotaNew, "GET", { env })).status, 405)` e conferir `headers.get("Allow") === "POST"`.
