# Relatório do Agente 3: Teste, Auditoria de Segurança e Validação

Projeto: `P26-2B-1768-7598-7D8E-716E` (Batalha Naval Tático: Cloudflare Pages Functions + D1 + Discord OAuth2)
Data: 20/11/2026. Auditoria independente: não li `relatorios/agente1.md`, `relatorios/agente2.md` nem o backup.

## 1. Escopo

- Todo o código de `functions/`, `lib/`, `migrations/`, `public/`, `wrangler.jsonc`, `LICENSE` e `README.md`, lido do zero com olhar de atacante.
- Só escrevi em `tests/teste-api.mjs` (casos novos) e em `/home/claude/devtools/` (`ataque.mjs`, `ui3.py`, `servidor.mjs` atualizado com backup em `servidor.mjs.orig`, screenshots em `shots/` e `shots_srv/`). O código de produção não foi alterado.

## 2. Metodologia

1. **Revisão estática** de cada rota, de `lib/` e das migrações.
2. **Execução em runtime real da Cloudflare (local).** Instalei o `wrangler@4` (4.166) em `/tmp/wr` e rodei `wrangler pages dev` sobre **cópias** do projeto (`/tmp/proj` com as migrações aplicadas via `wrangler d1 migrations apply DB --local`, e `/tmp/proj2` sem migrações, para testar o `ensureSchema`). Com isso as Functions rodam no **workerd** com o **D1 do miniflare**, que também é SQLite dentro de um Durable Object. Esse ambiente confirma de verdade:
   - o roteamento do Pages;
   - o `_middleware.js`;
   - o bundling dos imports `../lib`;
   - a semântica de `db.batch`, `changes()`, `RETURNING` e do índice único parcial.

   Numa das cópias criei uma rota de sondagem (`/api/sondagem`) e uma rota que lança exceção (`/api/explode`), que **não existem no projeto**.
3. **Bateria adversária HTTP**: `devtools/ataque.mjs`, com 113 verificações via HTTP e leitura do SQLite do D1 local para conferir o estado gravado.
4. **Interface**: Playwright e Chrome contra o wrangler (`ui3.py`, partida completa até a vitória, desktop e 390px). O roteiro antigo `ui2.py` também rodou contra o `servidor.mjs` atualizado.
5. **Bateria oficial**: `node tests/teste-api.mjs` (Node 22.23), ampliada com 16 casos novos (seção 6).

## 3. Casos executados

### 3.1 `tests/teste-api.mjs`: 67 aprovados, 0 reprovados

| Seção | Casos | Resultado |
|---|---|---|
| 1. Regras do jogo | 12 | 12 passaram |
| 2. Sessão assinada | 4 | 4 passaram |
| 3. Endpoints + D1 | 26 | 26 passaram |
| 4. OAuth2 | 4 | 4 passaram |
| 5. Rubrica | 5 | 5 passaram |
| **6. Auditoria adversária (novos, Agente 3)** | **16** | **16 passaram** |

Casos novos da seção 6:
- sessão expirada com assinatura válida → 401;
- sessão sem `userId` → 401;
- cookie com 3 partes, lixo base64 ou assinatura vazia → 401;
- 20 payloads hostis no `new` → 400 e nenhuma partida criada;
- `celulas`/`tamanho` forjados no payload são ignorados;
- 17 tipos estranhos no `fire` → 400;
- IDOR (Bob não afeta a partida de Alice);
- whitelist das chaves da resposta do tiro;
- tiro repetido com `-0`;
- corrida de 15 tiros simultâneos;
- corrida do último tiro 8 vezes em paralelo (placar contado 1 vez);
- corrida de 10 `new` simultâneos, em 2 rodadas;
- placar condicionado a `changes()`;
- username com SQL injection;
- `_middleware` transforma exceção em 500 sem detalhes internos;
- DDL do `ensureSchema` válido;
- varredura de vazamento em todas as respostas.

A bateria também imprime um **aviso** (que não reprova) sobre o defeito D1 abaixo.

### 3.2 Ataque HTTP no workerd/wrangler (`devtools/ataque.mjs`): 110 OK, 3 falhas

Rodei duas vezes, uma com o banco migrado e outra com o banco vazio (só `ensureSchema`). O resultado foi o mesmo nas duas.

| Grupo | Resultado |
|---|---|
| Rotas de jogo sem sessão (5) | Todas 401 |
| Cookie forjado (payload trocado, sem assinatura, assinatura vazia ou arbitrária, 3 partes, lixo base64, cookie de 5 KB, expirado, sem `userId`) | Todos 401 |
| Métodos errados: PUT/DELETE/PATCH/POST em rotas GET | 405 (passou) |
| **GET em rotas só POST (`/api/game/new`, `/api/game/fire`, `/api/auth/logout`)** | **200 com `index.html`: FALHOU (defeito D1)** |
| `new`: 27 payloads hostis (vazio, `null`, array, string, float, `1e309`, 2^53, negativo, `"h"`, array na orientação, id com SQLi, id objeto, `__proto__`, repetido, 4 ou 6 navios, sobreposição, corpo > 8 KB) | Todos 400; nenhuma partida criada |
| `fire`: 21 entradas estranhas (string, float, `null`, array, objeto, bool, 10, -1, `1e20`, campo ausente, `partidaId` string/SQLi/float/`null`, corpo não-JSON, `NaN` literal) | Todos 400 |
| `partidaId` 1e300 / negativo | 404, sem erro 500 |
| IDOR (`fire` na partida alheia) | 403 |
| Tiro repetido (inclusive com `-0`) / após o fim / desistir após o fim | 409 |
| 20 tiros simultâneos | 3×200 e 17×409, sem 5xx; tiros gravados = tiros aceitos |
| Último tiro 8× em paralelo | 1×200 e 7×409; placar com 1 vitória e 1 partida (sem contagem dupla) |
| 10× `new` simultâneos (2 rodadas) | Sempre 1 partida ativa; derrotas = partidas abandonadas; sem 5xx |
| Desistir e atirar ao mesmo tempo | 200/409, estado consistente |
| SQLi no username (`Robert'); DROP TABLE…`) | Gravado como texto; tabela intacta |
| Vazamento (`frota_servidor`, `celulas`, `navioId`, `versao`, stack) em **todas** as 107 respostas, inclusive erros e `/api/status` | Nenhum |
| OAuth2: inicia com `state`; `state` divergente ou ausente recusado; logout apaga o cookie | Passou |
| `_middleware`: exceção vira 500 JSON genérico, sem detalhes | Passou |

### 3.3 Interface (`ui3.py`, Chrome headless, workerd + D1 local): 28 OK, 0 falhas

- Posicionamento manual **horizontal e vertical** (botão e tecla R). A pré-visualização fica verde ou vermelha. Mover navio funciona. O corpo enviado ao `/api/game/new` contém navios H e V.
- Partida completa até a **vitória**: 19 cliques geraram exatamente **19 `fetch`** (um por bombardeio). As respostas só trouxeram `água`, `acerto` e `navio afundado`, sem chaves extras.
- Ao terminar, o placar pessoal e o **placar geral** foram atualizados na tela e no D1. "Nova partida" mantém a frota. Recarregar a página restaura a partida ativa. Desistir funciona. Sem sessão, aparece a tela de login.
- Em **390px**: sem rolagem horizontal da página (`scrollWidth` = 390), células de 28×28 px, disparo por toque funciona.
- Nenhum erro de JavaScript ou de console (fora o avatar do CDN do Discord, como esperado sem internet).
- `ui2.py` contra o `servidor.mjs`: 15/15 OK (foco por teclado, duplo clique gera 1 fetch, falha de rede, sessão expirada, 360px).

Screenshots revisados: `devtools/shots/a1_preview_vertical.png`, `a4_fim.png`, `a5_mobile.png` e outros.

### 3.4 Conformidade (reprodução manual; o `validar-local.mjs` não estava disponível)

| Item | Resultado |
|---|---|
| Tudo dentro de `P26-2B-1768-7598-7D8E-716E/` (estrutura `public/`, `functions/`, `lib/`, `migrations/`, `tests/`, `skills/`) | OK |
| Rodapé `<footer>` com a Chave Única | OK |
| `LICENSE` MIT | OK |
| Sem React/Vue/Angular/Svelte/jQuery, sem CDN externo de script | OK |
| `text-shadow` / `drop-shadow` | Só aparece `text-shadow: none !important` (`public/styles.css:9`). Ver risco R1. |
| `wrangler.jsonc` (nome, `pages_build_output_dir: ./public`, binding `DB`) | Válido (o wrangler 4 carregou), mas `database_id` é um placeholder. Ver D2. |
| Queries parametrizadas | OK; nenhuma interpolação em `prepare()` |

## 4. Defeitos encontrados (do mais grave para o menos grave)

Nenhum defeito crítico ou alto de segurança foi encontrado. A matriz do oponente não vaza, a sessão não pode ser forjada, IDOR e corridas estão tratados.

### D2. MÉDIO (bloqueante de entrega, configuração): `database_id` placeholder no `wrangler.jsonc`, que é a fonte da verdade no Pages
- **Evidência:** em `wrangler.jsonc:10`, `"database_id": "00000000-0000-0000-0000-000000000000"`. A documentação da Cloudflare diz que, com `pages_build_output_dir`, o arquivo de configuração **"becomes the source of truth"** e os mesmos campos deixam de ser editáveis no painel.
- **Impacto:** o passo 4 do README (vincular o D1 pelo painel) não se aplica ou é sobrescrito. Com o ID falso, o deploy falha ou o binding `DB` não funciona. O código responderia 503 `d1_indisponivel`, ou `/api/status` mostraria `d1Connected: false`.
- **Correção:** antes do deploy, colar o `database_id` real gerado por `wrangler d1 create` no `wrangler.jsonc` (o passo 3 do README já pede isso) e, depois do deploy, conferir `GET /api/status` → `d1Connected: true`. Opcionalmente, ajustar o texto do passo 4 do README.

### D1. BAIXO: GET em rota só POST devolve `index.html` com status 200; métodos errados devolvem 405 sem JSON
- **Evidência:** `functions/api/game/new.js`, `fire.js`, `surrender.js`, `auth/logout.js` (e `state.js`, `placar.js`, `me.js` para POST) só exportam `onRequestPost`/`onRequestGet`. No workerd: `curl /api/game/fire` → `200 text/html` (fallback SPA do Pages). `PUT /api/game/fire` → 405 sem corpo JSON. `GET /api/naoexiste` → 200 HTML.
- **Impacto:** não há impacto de segurança, porque nada é criado nem alterado. Mas é uma API que responde HTML 200 a um método errado, o que pode pesar num avaliador que testar com GET.
- **Correção:** em cada rota, acrescentar `export const onRequest = () => json({ ok:false, error:"method_not_allowed" }, 405, { Allow: "POST" });`, como já é feito em `status.js`. Confirmei no workerd que o handler específico do método tem precedência: `GET /api/status` → 200 e `PUT` → 405 JSON. Outra opção é um `functions/api/[[catchall]].js` que devolve 404 JSON.

### D3. BAIXO (UX): ranking esconde as colunas de pontuação no celular quando há nome longo
- **Evidência:** `public/styles.css:328` (`.ranking td { white-space: nowrap; }`) junto com `.tabela-wrap { overflow-x: auto; }`. Em 390px com um nome longo (o `global_name` do Discord pode ter até 32 caracteres e o servidor aceita até 80), Vitórias, Derrotas e Precisão só aparecem rolando a tabela na horizontal (ver `shots/a5_mobile.png`). A página em si não rola.
- **Correção:** limitar a célula do nome (`max-width: 40vw; overflow: hidden; text-overflow: ellipsis;`) ou permitir quebra de linha nela.

### D4. BAIXO: logout é só no cliente (sessão sem estado)
- **Evidência:** `functions/api/auth/logout.js` só manda o cookie com `Max-Age=0`. Um token copiado antes continua válido até o `exp` (7 dias). Confirmado pelo `ataque.mjs` [11].
- **Correção (opcional):** lista de revogação ou `sessao_versao` por usuário no D1, ou validade menor. Para um trabalho escolar, é aceitável se documentado.

### D5. INFORMATIVO
- `ensureSchema` (`lib/session.js:126`) cria `batalha_partidas` **sem** o `CHECK (status IN …)` da migração 0002. Se a tabela nascer pelo `ensureSchema`, a migração vira no-op e o CHECK não existe. Não há impacto prático, porque todos os valores são fixos no código.
- `fire.js` devolve 403 para a partida de outro jogador e 404 para uma inexistente, o que permite saber se um ID existe. É uma enumeração de IDs sem dados; aceitável.
- `frotaAleatoria`/IA usam `Math.random`. Prever o estado do PRNG a partir dos tiros do servidor é teórico. Sugestão: `crypto.getRandomValues`.
- **`AGENTS.md` está desatualizado em relação a esta auditoria.** Ele diz que o Agente 3 executou o `validar-local.mjs` e que a bateria tem "51 casos". O validador não estava disponível aqui e a bateria agora tem **67**. O defeito `[hidden]` citado ali eu não vi (o CSS atual já está correto). O orquestrador deve alinhar a seção do Agente 3 com este relatório. Não alterei o arquivo porque está fora do meu escopo.

## 5. O que foi confirmado na documentação da Cloudflare (e no runtime local)

| Item | Docs oficiais | Runtime local (workerd + D1 do miniflare) |
|---|---|---|
| `db.batch()` é transação, sequencial, e faz rollback total em erro | **Confirmado**: "Batched statements are SQL transactions"; executa "sequentially, non-concurrently"; em falha, "aborts or rolls back the entire sequence" (developers.cloudflare.com/d1/worker-api/d1-database) | Confirmado: um INSERT antes de um erro UNIQUE foi revertido |
| `changes()` dentro do batch reflete o statement anterior | **Não documentado** (as páginas de SQL e de prepared statements não citam `changes()`) | **Funciona**: UPDATE com 1 linha → INSERT condicional gravou; UPDATE com 0 linhas → não gravou; o placar não conta duas vezes sob corrida |
| `RETURNING` | Não citado nas páginas consultadas (a página de prepared statements diz que `results` vem vazio em escrita, sem tratar de RETURNING) | Funciona dentro do batch (`results` traz a linha) |
| Índice único parcial | **Confirmado** (página "Use indexes": partial indexes e `CREATE UNIQUE INDEX`) | Funciona; a mensagem de erro contém "UNIQUE" (`D1_ERROR: UNIQUE constraint failed…`), como `new.js` espera |
| `meta.changes` | Confirmado como "the number of changes made to the database" (Return objects) | 1 ou 0, conforme esperado |
| `_middleware.js` | Recurso documentado do Pages Functions | Funciona: exceção vira 500 JSON genérico |
| Imports de `../lib` fora de `functions/` | Não há página específica | O bundler do wrangler compilou e executou sem aviso (o deploy do Pages usa o mesmo bundler) |
| `onRequest` e `onRequestGet` no mesmo arquivo | A página de routing não trata disso | O handler do método tem precedência (`status.js`: GET 200, PUT 405) |
| Rota sem handler para o método | Documentado: "If no Function is matched, it will fall back to a static asset" | Confirmado (origem do D1) |
| `wrangler.jsonc` com `pages_build_output_dir` | **Confirmado**: suportado desde o wrangler 3.91 e passa a ser a fonte da verdade | Origem do D2 |

**Risco declarado:** a condição `changes()` depende de o D1 executar o batch numa única conexão SQLite. A doc confirma que o batch é uma transação sequencial, e o D1 do miniflare usa a mesma arquitetura (SQLite num Durable Object), onde funciona. Mas **não há frase oficial sobre `changes()`**, e não pude testar no D1 de produção (sem conta ou deploy aqui). Se em produção `changes()` não refletisse o UPDATE anterior, o efeito seria o placar **não** ser gravado no fim de partida, porque a condição falharia, e não uma gravação dupla. **Teste recomendado após o deploy:** jogar uma partida até o fim e conferir `/api/placar`.

## 6. Riscos residuais

1. `changes()` no D1 de produção não foi verificado em produção (ver acima). Mitigação: smoke test após o deploy.
2. Login com o Discord real não foi testado ponta a ponta (sem internet). O fluxo foi coberto com Discord simulado. Exige o Redirect URI exato no Developer Portal.
3. R1: o `text-shadow: none !important` em `styles.css:9` é inofensivo, mas um validador que procure só pela string `text-shadow` poderia marcá-lo. Remover essa regra elimina o risco sem efeito visual.
4. O `ensureSchema` roda em todo isolate frio (um batch de DDL e um UPDATE). Custo pequeno, aceitável.
5. `SESSION_SECRET` é opcional e cai no `DISCORD_CLIENT_SECRET`. Recomendo definir um segredo próprio.

## 7. Veredito

**O código está pronto do ponto de vista de segurança e funcionalidade**: todos os requisitos da especificação foram verificados em runtime equivalente ao da Cloudflare, sem vazamento, sem bypass de sessão, sem IDOR e com corridas consistentes. O total foi de 67/67 na bateria, 110/113 no ataque HTTP (as 3 falhas são o defeito D1, de baixa gravidade) e 28/28 na interface.

**A entrega ainda NÃO está pronta como está**: falta corrigir o **D2** (`database_id` real no `wrangler.jsonc`) e fazer o deploy com o smoke test (`/api/status` com `d1Connected: true` e uma partida completa atualizando o `/api/placar`). Também falta preencher a URL real no README e alinhar o `AGENTS.md` com este relatório. As correções de D1 e D3 são recomendadas, mas não bloqueiam.

---

## Rodada 2: reteste de regressão (independente)

**Ambiente:** cópia nova do projeto atual em `/tmp/proj`, migrações aplicadas no D1 local, `wrangler pages dev` (workerd + D1 do miniflare). Meu script de interface antigo (`devtools/ui3.py`) foi sobrescrito por outro agente, então recriei o teste como `devtools/ui_agente3.py`. Os screenshots desta rodada estão em `devtools/shots2/`.

### Status dos defeitos

| Defeito | Correção aplicada | Verificação independente | Status |
|---|---|---|---|
| **D1**: método errado → `index.html` 200 / 405 sem JSON | `onRequest` de fallback em todas as rotas, via `metodoNaoPermitido()` (`lib/session.js:107`) | **No workerd:** GET/PUT/DELETE/PATCH em rotas só-POST e POST/PUT/DELETE em rotas só-GET → 405 `application/json`, `{"error":"method_not_allowed"}` e `Allow` correto (12 combinações no ataque HTTP). Os handlers dos métodos certos continuam com precedência.<br>**Na bateria:** 10 rotas × 4 métodos errados cada → 405 com `Allow` correto, sem efeito colateral no banco. | **Corrigido** |
| D5 (info): `ensureSchema` sem CHECK | CHECK igual ao da migração 0002 (`lib/session.js:140`) | Na bateria, o DDL do `ensureSchema` recusa `status='hackeado'` | **Corrigido** |
| **D2**: `database_id` placeholder | README, passo 4, reescrito: o binding vem do `wrangler.jsonc`, o ID precisa ser o real, e confere-se com `/api/status` → `d1Connected:true`. O ID continua placeholder **de propósito** (só o estudante pode gerar o real). | README conferido; o texto está correto e consistente com a documentação da Cloudflare | **Documentado; ação do estudante antes do deploy (bloqueante para o deploy, não para o código)** |
| **D3**: ranking esconde colunas no celular | Célula do nome com reticências (`.col-nome`, `.nome` em `styles.css:330-333`) | Com um nome de 37 caracteres no ranking, em 360px e 390px a tabela não rola (`scrollWidth` = `clientWidth`), todos os cabeçalhos ficam visíveis e o nome aparece truncado ("Robert'); DROP TABL…"). Ver `shots2/b5_mobile_390.png`. O nome continua inserido como texto, sem HTML. | **Corrigido** |
| **D4**: logout não revoga o token | Nenhuma correção (decisão do coordenador) | Comportamento inalterado: o token reapresentado continua válido até o `exp` (7 dias) | **Risco aceito e documentado** |
| R1: `text-shadow: none !important` | Mantido (vem do template do professor) | Não há outra ocorrência de `text-shadow` nem `drop-shadow` | Mantido por decisão do coordenador |

### Contagens finais

| Bateria | Rodada 1 | Rodada 2 |
|---|---|---|
| `node tests/teste-api.mjs` | 67 / 0 falhas | **79 / 0 falhas**. Entrou a seção 7, com 12 casos novos: 405 JSON + `Allow` para 4 rotas só-POST e 6 rotas só-GET, métodos errados sem efeito no banco e CHECK do `ensureSchema`. O aviso da seção 6 foi substituído por esses testes. |
| Ataque HTTP (`devtools/ataque.mjs`, workerd) | 110 OK / 3 falhas | **115 OK / 0 falhas**. O critério ficou mais rígido (exige 405 + JSON + `Allow`) e cobre 2 rotas a mais. Nenhum vazamento em 109 respostas. Corridas continuam consistentes: 20 tiros simultâneos dão 3×200 e 17×409; o último tiro 8× dá 1 vitória e placar contado uma vez; `new` 10× deixa sempre 1 partida ativa, com derrotas = abandonadas. |
| Interface (`devtools/ui_agente3.py`, Chrome) | 28 OK | **26 OK / 1 falha do roteiro, não da aplicação.** Partida completa com navios H e V, 19 fetch para 19 cliques, só água/acerto/navio afundado, vitória, placar pessoal e geral atualizados, restauração ao recarregar, 360/390px sem rolagem com ranking completo, disparo por toque, desistir, tela de login. Nenhum erro de JavaScript. A "falha" é o console registrar os 401 de `/api/game/state` e `/api/me` na página **deslogada**: são as respostas esperadas, que o app usa para saber que não há sessão. Não é defeito. |

### Regressões

Nenhuma encontrada. Pontos reconferidos:
- a matriz do oponente não aparece em nenhuma resposta;
- sessão forjada → 401;
- IDOR → 403;
- tiro repetido ou após o fim → 409;
- payloads hostis → 400;
- `_middleware` → 500 JSON genérico;
- rodapé com a Chave Única;
- sem frameworks;
- `innerHTML` só com conteúdo fixo ou para limpar elementos.

### Observação residual (baixa, fora do escopo de D1)

Uma rota **inexistente** sob `/api/` (ex.: `GET /api/naoexiste`) ainda devolve `index.html` com 200, pelo fallback de SPA do Pages. Não tem impacto de segurança. Se quiserem, um `functions/api/[[catchall]].js` que devolve 404 JSON fecha o caso.

### Veredito final do código

**O código está aprovado para entrega.** Todos os defeitos de código (D1, D3 e o CHECK) estão corrigidos e verificados em runtime equivalente ao da Cloudflare, sem regressões. O D4 é um risco aceito e documentado. A pendência que sobra é **operacional e do estudante**:
- colocar o `database_id` real no `wrangler.jsonc`;
- fazer o deploy;
- fazer o smoke test: `/api/status` com `d1Connected:true` e uma partida até o fim aparecendo no `/api/placar`, o que também valida o `changes()` no D1 de produção;
- preencher `URL_CLOUDFLARE` no README;
- alinhar a seção do Agente 3 no `AGENTS.md` com este relatório.
