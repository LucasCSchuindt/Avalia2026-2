/**
 * Batalha Naval Tático — cliente em JavaScript puro (Vanilla JS, DOM nativo).
 * O cliente só cuida da interface. Toda regra (validação da frota, resultado dos
 * disparos, IA do oponente e placar) roda nas Cloudflare Pages Functions.
 */
"use strict";

const CHAVE_PROJETO = "P26-2B-1768-7598-7D8E-716E";
const TAM = 10;
const LETRAS = "ABCDEFGHIJ";

const FROTA = [
  { id: "porta-avioes", nome: "Porta-aviões", tamanho: 5 },
  { id: "encouracado", nome: "Encouraçado", tamanho: 4 },
  { id: "cruzador", nome: "Cruzador", tamanho: 3 },
  { id: "submarino", nome: "Submarino", tamanho: 3 },
  { id: "destroier", nome: "Destróier", tamanho: 2 },
];

const estado = {
  user: null,
  fase: "posicionamento", // posicionamento | combate | fim
  colocacao: {},          // id -> { linha, coluna, orientacao }
  selecionado: FROTA[0].id,
  orientacao: "H",
  partida: null,          // visão pública vinda do servidor
  ultimoJogador: null,
  ultimoServidor: null,
  aguardando: false,
};

const $ = (id) => document.getElementById(id);

// Avatar padrão local (SVG embutido): usado se o CDN do Discord falhar ou a URL não for do Discord.
const AVATAR_PADRAO = "data:image/svg+xml," + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><circle cx="16" cy="16" r="16" fill="#5865f2"/>' +
  '<circle cx="16" cy="13" r="6" fill="#fff"/><path d="M5 28c2-6 6-8 11-8s9 2 11 8" fill="#fff"/></svg>');

function aplicarAvatar(img, url) {
  img.onerror = () => { img.onerror = null; img.src = AVATAR_PADRAO; };
  img.src = typeof url === "string" && url.startsWith("https://cdn.discordapp.com/") ? url : AVATAR_PADRAO;
}
const nomeCoord = (l, c) => LETRAS[c] + (l + 1);

/* ---------------- API ---------------- */

async function api(caminho, opcoes = {}) {
  let res;
  try {
    res = await fetch(caminho, {
      credentials: "same-origin",
      headers: opcoes.body ? { "Content-Type": "application/json" } : undefined,
      ...opcoes,
      body: opcoes.body ? JSON.stringify(opcoes.body) : undefined,
    });
  } catch {
    // Falha de rede: nunca lança, para a interface não ficar travada em "aguardando".
    return { status: 0, ok: false, dados: { message: "Sem conexão com o servidor. Verifique sua internet e tente de novo." } };
  }
  let dados = null;
  try { dados = await res.json(); } catch { dados = null; }
  return { status: res.status, ok: res.ok, dados: dados || {} };
}

/* ---------------- Mensagens ---------------- */

function mostrarAlerta(texto) {
  const el = $("alerta");
  if (!texto) { el.hidden = true; el.textContent = ""; return; }
  el.textContent = texto;
  el.hidden = false;
}

function log(texto, classe = "") {
  const el = $("log");
  el.textContent = texto;
  el.className = "log" + (classe ? " " + classe : "");
}

const ERROS_AUTH = {
  invalid_state: "A sessão de login expirou. Tente entrar novamente.",
  token_exchange_failed: "O Discord recusou o login. Confira o Client Secret e o Redirect URI.",
  fetch_user_failed: "Não foi possível obter seu perfil do Discord.",
  missing_credentials: "Login com Discord não configurado neste deploy.",
  access_denied: "Você cancelou o login com o Discord.",
};

/* ---------------- Cabeçalho Discord ---------------- */

function renderDiscordHeader() {
  const logado = Boolean(estado.user);
  $("discordLoginLink").hidden = logado;
  $("discordUser").hidden = !logado;
  if (logado) {
    $("discordUsername").textContent = estado.user.username;
    $("discordUserId").textContent = "user_id: " + estado.user.userId;
    aplicarAvatar($("discordAvatar"), estado.user.avatar);
  }
}

/* ---------------- Malhas ---------------- */

function criarGrade(container, tipo) {
  container.innerHTML = "";
  const canto = document.createElement("span");
  canto.className = "rotulo";
  container.appendChild(canto);
  for (let c = 0; c < TAM; c++) {
    const r = document.createElement("span");
    r.className = "rotulo";
    r.textContent = LETRAS[c];
    container.appendChild(r);
  }
  for (let l = 0; l < TAM; l++) {
    const r = document.createElement("span");
    r.className = "rotulo";
    r.textContent = String(l + 1);
    container.appendChild(r);
    for (let c = 0; c < TAM; c++) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "celula";
      b.dataset.l = String(l);
      b.dataset.c = String(c);
      b.dataset.tipo = tipo;
      b.setAttribute("aria-label", nomeCoord(l, c));
      b.tabIndex = l === 0 && c === 0 ? 0 : -1;
      container.appendChild(b);
    }
  }
}

/* Navegação por teclado: só uma célula de cada malha entra no Tab; setas movem o foco. */
function ativarNavegacaoTeclado(grade) {
  grade.addEventListener("focusin", (e) => {
    const el = e.target.closest(".celula");
    if (!el) return;
    grade.querySelectorAll('.celula[tabindex="0"]').forEach((x) => { if (x !== el) x.tabIndex = -1; });
    el.tabIndex = 0;
  });
  grade.addEventListener("keydown", (e) => {
    const el = e.target.closest(".celula");
    if (!el) return;
    let l = Number(el.dataset.l), c = Number(el.dataset.c);
    switch (e.key) {
      case "ArrowUp": l--; break;
      case "ArrowDown": l++; break;
      case "ArrowLeft": c--; break;
      case "ArrowRight": c++; break;
      case "Home": c = 0; break;
      case "End": c = TAM - 1; break;
      default: return;
    }
    e.preventDefault();
    l = Math.max(0, Math.min(TAM - 1, l));
    c = Math.max(0, Math.min(TAM - 1, c));
    celula(grade, l, c)?.focus();
  });
}

function bloqueada(el) {
  return el.getAttribute("aria-disabled") === "true";
}

function celula(grade, l, c) {
  return grade.querySelector(`.celula[data-l="${l}"][data-c="${c}"]`);
}

function celulasNavio(linha, coluna, tamanho, orientacao) {
  const out = [];
  for (let i = 0; i < tamanho; i++) out.push(orientacao === "H" ? [linha, coluna + i] : [linha + i, coluna]);
  return out;
}

function mapaOcupacao(excetoId) {
  const m = new Map();
  for (const navio of FROTA) {
    const p = estado.colocacao[navio.id];
    if (!p || navio.id === excetoId) continue;
    for (const [l, c] of celulasNavio(p.linha, p.coluna, navio.tamanho, p.orientacao)) m.set(l * TAM + c, navio.id);
  }
  return m;
}

function posicaoValida(id, linha, coluna, orientacao) {
  const navio = FROTA.find((n) => n.id === id);
  const ocup = mapaOcupacao(id);
  return celulasNavio(linha, coluna, navio.tamanho, orientacao)
    .every(([l, c]) => l >= 0 && l < TAM && c >= 0 && c < TAM && !ocup.has(l * TAM + c));
}

/* ---------------- Renderização ---------------- */

function limparClasses(grade) {
  grade.querySelectorAll(".celula").forEach((el) => {
    el.className = "celula";
    el.removeAttribute("aria-disabled");
    el.setAttribute("aria-label", nomeCoord(Number(el.dataset.l), Number(el.dataset.c)));
  });
}

function marcar(el, classe, descricao) {
  if (!el) return;
  el.classList.add(classe);
  el.setAttribute("aria-label", nomeCoord(Number(el.dataset.l), Number(el.dataset.c)) + ": " + descricao);
}

function marcarUltimo(el, descricao) {
  if (!el) return;
  el.classList.add("ultimo");
  el.setAttribute("aria-label", el.getAttribute("aria-label") + " (" + descricao + ")");
}

function classeResultado(resultado) {
  if (resultado === "água") return "agua";
  if (resultado === "acerto") return "acerto";
  return "afundado";
}

function renderGradeJogador() {
  const grade = $("gradeJogador");
  limparClasses(grade);
  grade.classList.toggle("posicionando", estado.fase === "posicionamento");
  // Fora do posicionamento a malha é só leitura (continua navegável por teclado/leitor de tela).
  if (estado.fase !== "posicionamento") grade.querySelectorAll(".celula").forEach((el) => el.setAttribute("aria-disabled", "true"));

  if (estado.fase === "posicionamento") {
    for (const navio of FROTA) {
      const p = estado.colocacao[navio.id];
      if (!p) continue;
      for (const [l, c] of celulasNavio(p.linha, p.coluna, navio.tamanho, p.orientacao)) marcar(celula(grade, l, c), "navio", navio.nome);
    }
    return;
  }

  const partida = estado.partida;
  if (!partida) return;
  const atingidas = new Set(partida.tirosServidor.map((t) => t.linha * TAM + t.coluna));
  for (const navio of partida.frotaJogador) {
    const cels = celulasNavio(navio.linha, navio.coluna, navio.tamanho, navio.orientacao);
    const afundou = cels.every(([l, c]) => atingidas.has(l * TAM + c));
    for (const [l, c] of cels) {
      const el = celula(grade, l, c);
      if (afundou) marcar(el, "afundado", "seu navio afundado");
      else if (atingidas.has(l * TAM + c)) marcar(el, "acerto", "seu navio atingido");
      else marcar(el, "navio", "seu navio");
    }
  }
  for (const t of partida.tirosServidor) {
    const el = celula(grade, t.linha, t.coluna);
    if (t.resultado === "água") marcar(el, "agua", "água");
  }
  if (estado.ultimoServidor) marcarUltimo(celula(grade, estado.ultimoServidor.linha, estado.ultimoServidor.coluna), "último tiro inimigo");
}

function renderGradeInimiga() {
  const grade = $("gradeInimiga");
  limparClasses(grade);
  const ativo = estado.fase === "combate" && !estado.aguardando;
  grade.classList.toggle("clicavel", ativo);
  $("cardInimigo").classList.toggle("inativo", estado.fase === "posicionamento");

  grade.setAttribute("aria-busy", String(estado.aguardando));
  // aria-disabled (e não disabled) para o foco do teclado não se perder enquanto o servidor responde.
  grade.querySelectorAll(".celula").forEach((el) => { if (!ativo) el.setAttribute("aria-disabled", "true"); });

  if (!estado.partida || estado.fase === "posicionamento") return;
  for (const t of estado.partida.tirosJogador) {
    const el = celula(grade, t.linha, t.coluna);
    marcar(el, classeResultado(t.resultado), t.resultado);
    el?.setAttribute("aria-disabled", "true");
  }
  if (estado.ultimoJogador) marcarUltimo(celula(grade, estado.ultimoJogador.linha, estado.ultimoJogador.coluna), "seu último tiro");
}

function renderFrotaLista() {
  const lista = $("frotaLista");
  lista.innerHTML = "";
  for (const navio of FROTA) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "navio-btn" + (estado.colocacao[navio.id] ? " posicionado" : "");
    b.setAttribute("aria-pressed", String(estado.selecionado === navio.id));
    if (estado.colocacao[navio.id]) b.setAttribute("aria-description", "já posicionado");
    b.dataset.id = navio.id;
    const nome = document.createElement("span");
    nome.textContent = navio.nome + " (" + navio.tamanho + ")";
    const blocos = document.createElement("span");
    blocos.className = "blocos";
    blocos.setAttribute("aria-hidden", "true");
    for (let i = 0; i < navio.tamanho; i++) blocos.appendChild(document.createElement("i"));
    b.append(blocos, nome);
    b.addEventListener("click", () => {
      estado.selecionado = navio.id;
      renderTudo();
      $("frotaLista").querySelector('[data-id="' + navio.id + '"]')?.focus();
    });
    lista.appendChild(b);
  }
}

function renderPlacar(placar) {
  if (!placar) return;
  $("pVitorias").textContent = placar.vitorias;
  $("pDerrotas").textContent = placar.derrotas;
  $("pPartidas").textContent = placar.partidas;
  $("pPrecisao").textContent = placar.tiros_total > 0
    ? Math.round((placar.acertos_total / placar.tiros_total) * 100) + "%"
    : "—";
}

function renderFase() {
  const pill = $("pillFase");
  const completos = FROTA.every((n) => estado.colocacao[n.id]);
  $("controlesPosicionamento").hidden = estado.fase !== "posicionamento";
  $("controlesCombate").hidden = estado.fase !== "combate";
  $("controlesFim").hidden = estado.fase !== "fim";
  $("btnIniciar").disabled = !completos || estado.aguardando;
  $("btnOrientacao").textContent = "Orientação: " + (estado.orientacao === "H" ? "Horizontal ↔" : "Vertical ↕");
  $("btnOrientacao").setAttribute("aria-pressed", String(estado.orientacao === "V"));

  if (estado.fase === "posicionamento") {
    pill.textContent = "Fase 1 · Posicionamento";
    pill.className = "pill";
    $("tituloFase").textContent = "Posicione sua frota";
    $("instrucao").innerHTML = "Escolha um navio, defina a orientação e clique na sua malha. Tecla <kbd>R</kbd> gira o navio. Clique num navio já posicionado para movê-lo.";
  } else if (estado.fase === "combate") {
    pill.textContent = "Fase 2 · Combate";
    pill.className = "pill combate";
    $("tituloFase").textContent = "Bombardeie as águas inimigas";
    $("instrucao").textContent = "Clique numa coordenada da malha inimiga. O servidor responde se foi água, acerto ou navio afundado — e contra-ataca em seguida.";
    $("contadorInimigo").textContent = "Navios inimigos afundados: " + estado.partida.naviosInimigosAfundados + "/" + estado.partida.totalNavios;
  } else {
    pill.textContent = "Confronto encerrado";
    pill.className = "pill fim";
    $("tituloFase").textContent = estado.partida && estado.partida.status === "vitoria" ? "Vitória! Frota inimiga destruída" : "Fim de jogo";
    $("instrucao").textContent = "O placar geral já foi atualizado no Cloudflare D1. Monte uma nova frota para jogar de novo.";
  }
}

function renderTudo() {
  renderFase();
  renderFrotaLista();
  renderGradeJogador();
  renderGradeInimiga();
}

/* ---------------- Posicionamento ---------------- */

function limparPreview() {
  $("gradeJogador").querySelectorAll(".preview-ok, .preview-ruim").forEach((el) => el.classList.remove("preview-ok", "preview-ruim"));
}

function mostrarPreview(l, c) {
  limparPreview();
  if (estado.fase !== "posicionamento" || !estado.selecionado) return;
  const navio = FROTA.find((n) => n.id === estado.selecionado);
  const ok = posicaoValida(navio.id, l, c, estado.orientacao);
  for (const [pl, pc] of celulasNavio(l, c, navio.tamanho, estado.orientacao)) {
    const el = celula($("gradeJogador"), pl, pc);
    if (el) el.classList.add(ok ? "preview-ok" : "preview-ruim");
  }
}

function proximoNaoPosicionado() {
  const n = FROTA.find((f) => !estado.colocacao[f.id]);
  return n ? n.id : null;
}

function cliqueMinhaGrade(l, c) {
  if (estado.fase !== "posicionamento") return;
  const ocup = mapaOcupacao(null);
  const idNaCelula = ocup.get(l * TAM + c);

  // Clicar num navio posicionado: pega ele de volta para mover
  if (idNaCelula && idNaCelula !== estado.selecionado) {
    const p = estado.colocacao[idNaCelula];
    delete estado.colocacao[idNaCelula];
    estado.selecionado = idNaCelula;
    estado.orientacao = p.orientacao;
    renderTudo();
    mostrarPreview(l, c);
    return;
  }
  if (!estado.selecionado) return;
  if (!posicaoValida(estado.selecionado, l, c, estado.orientacao)) {
    log("Posição inválida: o navio sairia da malha ou ficaria sobreposto.");
    return;
  }
  estado.colocacao[estado.selecionado] = { linha: l, coluna: c, orientacao: estado.orientacao };
  estado.selecionado = proximoNaoPosicionado();
  log(estado.selecionado ? "Navio posicionado. Próximo: " + FROTA.find((n) => n.id === estado.selecionado).nome + "." : "Frota completa! Clique em “Iniciar batalha”.");
  renderTudo();
}

function posicionarAleatorio() {
  for (let tentativa = 0; tentativa < 500; tentativa++) {
    estado.colocacao = {};
    let ok = true;
    for (const navio of FROTA) {
      let colocado = false;
      for (let t = 0; t < 200 && !colocado; t++) {
        const o = Math.random() < 0.5 ? "H" : "V";
        const l = Math.floor(Math.random() * TAM);
        const c = Math.floor(Math.random() * TAM);
        if (posicaoValida(navio.id, l, c, o)) {
          estado.colocacao[navio.id] = { linha: l, coluna: c, orientacao: o };
          colocado = true;
        }
      }
      if (!colocado) { ok = false; break; }
    }
    if (ok) break;
  }
  estado.selecionado = null;
  log("Frota posicionada aleatoriamente. Ajuste se quiser e clique em “Iniciar batalha”.");
  renderTudo();
}

function girar() {
  estado.orientacao = estado.orientacao === "H" ? "V" : "H";
  renderFase();
  const foco = document.activeElement;
  if (foco && foco.dataset && foco.dataset.tipo === "jogador") mostrarPreview(Number(foco.dataset.l), Number(foco.dataset.c));
}

async function iniciarBatalha() {
  if (estado.aguardando) return;
  const navios = FROTA.map((n) => ({ id: n.id, ...estado.colocacao[n.id] }));
  estado.aguardando = true;
  renderFase();
  log("Enviando frota para validação no servidor…");
  const r = await api("/api/game/new", { method: "POST", body: { navios } });
  estado.aguardando = false;
  if (!r.ok) {
    tratarErro(r);
    renderTudo();
    return;
  }
  mostrarAlerta(null);
  estado.partida = r.dados.partida;
  estado.fase = "combate";
  estado.ultimoJogador = estado.ultimoServidor = null;
  renderPlacar(r.dados.placar);
  log("Frota validada pelo servidor. Combate iniciado — sua vez de atirar!");
  renderTudo();
  // O botão "Iniciar" some: leva o foco para a malha inimiga em vez de deixá-lo no <body>.
  $("gradeInimiga").querySelector('.celula[tabindex="0"]')?.focus();
}

/* ---------------- Combate ---------------- */

async function disparar(l, c) {
  if (estado.fase !== "combate" || estado.aguardando) return;
  if (estado.partida.tirosJogador.some((t) => t.linha === l && t.coluna === c)) return;

  estado.aguardando = true;
  renderGradeInimiga();
  log("Bombardeando " + nomeCoord(l, c) + "…");

  const r = await api("/api/game/fire", { method: "POST", body: { partidaId: estado.partida.id, linha: l, coluna: c } });
  estado.aguardando = false;

  if (!r.ok) {
    tratarErro(r);
    if (r.status === 0) { renderGradeInimiga(); return; } // sem rede: mantém a partida e permite tentar de novo
    if (r.status !== 401) await carregarEstado();
    return;
  }

  const d = r.dados;
  estado.partida.tirosJogador.push({ linha: l, coluna: c, resultado: d.resultado });
  if (d.resultado === "navio afundado") estado.partida.naviosInimigosAfundados++;
  estado.ultimoJogador = { linha: l, coluna: c };
  estado.ultimoServidor = d.tiroServidor ? { linha: d.tiroServidor.linha, coluna: d.tiroServidor.coluna } : null;
  if (d.tiroServidor) estado.partida.tirosServidor.push(d.tiroServidor);

  let msg = nomeCoord(l, c) + ": " + d.resultado.toUpperCase() + ".";
  if (d.tiroServidor) msg += " Inimigo atirou em " + nomeCoord(d.tiroServidor.linha, d.tiroServidor.coluna) + ": " + d.tiroServidor.resultado + ".";

  if (d.status !== "ativa") {
    estado.fase = "fim";
    estado.partida.status = d.status;
    renderPlacar(d.placar);
    if (d.vencedor === "jogador") log(msg + " 🏆 Você afundou toda a frota inimiga!", "vitoria");
    else log(msg + " Sua frota foi destruída. Derrota.", "derrota");
    carregarRanking();
  } else {
    log(msg);
  }
  renderTudo();
}

async function desistir() {
  if (estado.aguardando || !confirm("Desistir conta como derrota no placar. Confirmar?")) return;
  estado.aguardando = true;
  renderGradeInimiga();
  const r = await api("/api/game/surrender", { method: "POST" });
  estado.aguardando = false;
  if (!r.ok) {
    tratarErro(r);
    if (r.status === 409) await carregarEstado(); else renderGradeInimiga();
    return;
  }
  renderPlacar(r.dados.placar);
  estado.fase = "fim";
  estado.partida.status = "abandonada";
  log("Você desistiu da partida.", "derrota");
  renderTudo();
  $("btnNovaPartida").focus();
  carregarRanking();
}

function novaPartida() {
  estado.fase = "posicionamento";
  estado.partida = null;
  estado.selecionado = proximoNaoPosicionado();
  estado.ultimoJogador = estado.ultimoServidor = null;
  log("Reposicione sua frota (a anterior foi mantida) e inicie uma nova batalha.");
  renderTudo();
  $("btnIniciar").disabled ? $("frotaLista").querySelector("button")?.focus() : $("btnIniciar").focus();
}

function tratarErro(r) {
  if (r.status === 401) {
    estado.user = null;
    mostrarTelas();
    mostrarAlerta("Sua sessão expirou. Entre novamente com o Discord.");
    return;
  }
  mostrarAlerta(r.dados.message || "Erro ao comunicar com o servidor (" + r.status + ").");
}

/* ---------------- Ranking ---------------- */

async function carregarRanking() {
  const body = $("rankingBody");
  try {
    const r = await api("/api/placar");
    body.innerHTML = "";
    const lista = r.ok && Array.isArray(r.dados.ranking) ? r.dados.ranking : [];
    if (lista.length === 0) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 5;
      td.textContent = r.ok ? "Nenhuma partida finalizada ainda. Seja o primeiro!"
        : r.status === 0 ? "Placar indisponível: sem conexão com o servidor." : "Placar indisponível (D1 não conectado).";
      tr.appendChild(td);
      body.appendChild(tr);
      return;
    }
    lista.forEach((j, i) => {
      const tr = document.createElement("tr");
      if (estado.user && j.user_id === estado.user.userId) tr.className = "eu";
      const precisao = j.tiros_total > 0 ? Math.round((j.acertos_total / j.tiros_total) * 100) + "%" : "—";
      const tdPos = document.createElement("td");
      tdPos.textContent = String(i + 1);
      const tdNome = document.createElement("td");
      tdNome.className = "col-nome";
      const img = document.createElement("img");
      img.alt = "";
      img.width = 22;
      img.height = 22;
      aplicarAvatar(img, j.avatar);
      // Nome longo é truncado com reticências (CSS); o nome completo fica no title.
      const nome = document.createElement("span");
      nome.className = "nome";
      nome.textContent = j.username;
      nome.title = j.username;
      const wrap = document.createElement("span");
      wrap.className = "jogador";
      wrap.append(img, nome);
      tdNome.appendChild(wrap);
      tr.append(tdPos, tdNome);
      for (const v of [j.vitorias, j.derrotas, precisao]) {
        const td = document.createElement("td");
        td.textContent = String(v);
        tr.appendChild(td);
      }
      body.appendChild(tr);
    });
  } catch {
    body.textContent = "";
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 5;
    td.textContent = "Publique no Cloudflare Pages para ativar o placar.";
    tr.appendChild(td);
    body.appendChild(tr);
  }
}

/* ---------------- Sessão / inicialização ---------------- */

function mostrarTelas() {
  $("telaLogin").hidden = Boolean(estado.user);
  $("telaJogo").hidden = !estado.user;
  renderDiscordHeader();
}

async function carregarEstado() {
  const r = await api("/api/game/state");
  if (r.status === 401) { estado.user = null; mostrarTelas(); return; }
  if (!r.ok) {
    mostrarAlerta(r.dados.message || "Não foi possível carregar a partida.");
    // Sem /api/game/state (D1 fora, rede, deploy estático): ainda tenta mostrar o perfil, e nunca deixa as duas telas ocultas.
    if (r.status !== 0) {
      const me = await api("/api/me");
      if (me.ok && me.dados.user) estado.user = me.dados.user;
    }
    mostrarTelas();
    return;
  }
  estado.user = r.dados.user;
  renderPlacar(r.dados.placar);
  if (r.dados.partida) {
    estado.partida = r.dados.partida;
    estado.fase = "combate";
    for (const n of estado.partida.frotaJogador) estado.colocacao[n.id] = { linha: n.linha, coluna: n.coluna, orientacao: n.orientacao };
    log("Partida em andamento restaurada do Cloudflare D1. Sua vez de atirar!");
  } else if (estado.fase === "combate") {
    // A partida local não existe mais no servidor (encerrada em outra aba, por exemplo).
    estado.fase = "posicionamento";
    estado.partida = null;
    estado.ultimoJogador = estado.ultimoServidor = null;
    estado.selecionado = proximoNaoPosicionado();
    log("A partida não está mais ativa no servidor. Monte sua frota para uma nova batalha.");
  }
  mostrarTelas();
  renderTudo();
}

async function iniciar() {
  const params = new URLSearchParams(location.search);
  if (params.has("auth_error")) {
    const cod = params.get("auth_error");
    mostrarAlerta(ERROS_AUTH[cod] || "Falha no login com Discord (" + cod + ").");
  }
  if (params.has("auth_error") || params.has("login")) history.replaceState(null, "", location.pathname);

  criarGrade($("gradeJogador"), "jogador");
  criarGrade($("gradeInimiga"), "inimigo");

  ativarNavegacaoTeclado($("gradeJogador"));
  ativarNavegacaoTeclado($("gradeInimiga"));

  $("gradeJogador").addEventListener("click", (e) => {
    const el = e.target.closest(".celula");
    if (el && !bloqueada(el)) cliqueMinhaGrade(Number(el.dataset.l), Number(el.dataset.c));
  });
  const preview = (e) => {
    const el = e.target.closest(".celula");
    if (el) mostrarPreview(Number(el.dataset.l), Number(el.dataset.c));
  };
  $("gradeJogador").addEventListener("mouseover", preview);
  $("gradeJogador").addEventListener("focusin", preview);
  $("gradeJogador").addEventListener("mouseleave", limparPreview);

  $("gradeInimiga").addEventListener("click", (e) => {
    const el = e.target.closest(".celula");
    if (el && !bloqueada(el)) disparar(Number(el.dataset.l), Number(el.dataset.c));
  });

  document.addEventListener("keydown", (e) => {
    if ((e.key === "r" || e.key === "R") && estado.fase === "posicionamento" && !e.ctrlKey && !e.metaKey && !e.altKey && !e.repeat) girar();
  });

  $("btnOrientacao").addEventListener("click", girar);
  $("btnAleatorio").addEventListener("click", posicionarAleatorio);
  $("btnLimpar").addEventListener("click", () => {
    estado.colocacao = {};
    estado.selecionado = FROTA[0].id;
    log("Malha limpa. Posicione sua frota.");
    renderTudo();
  });
  $("btnIniciar").addEventListener("click", iniciarBatalha);
  $("btnDesistir").addEventListener("click", desistir);
  $("btnNovaPartida").addEventListener("click", novaPartida);
  $("logoutBtn").addEventListener("click", async () => {
    $("logoutBtn").disabled = true;
    await api("/api/auth/logout", { method: "POST" });
    location.href = "/";
  });

  renderTudo();

  try {
    await carregarEstado();
    if (!estado.user) {
      const me = await api("/api/me");
      if (me.dados && me.dados.discordConfigurado === false) $("notaConfig").hidden = false;
    }
  } catch {
    mostrarAlerta("Modo estático local. Publique no Cloudflare Pages para ativar as Functions e o D1.");
    $("telaLogin").hidden = false;
  }
  carregarRanking();
}

iniciar();
