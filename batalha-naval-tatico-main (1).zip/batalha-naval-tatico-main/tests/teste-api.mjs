/**
 * Bateria de testes do Agente de Teste e Validação — Batalha Naval Tático.
 * Executa as Cloudflare Pages Functions reais contra um banco SQLite em memória
 * que imita a API do Cloudflare D1 (prepare/bind/first/all/run/batch).
 *
 * Uso (Node 22+), a partir da subpasta do projeto:
 *   node tests/teste-api.mjs
 */
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

import { signSession, verifySession } from "../lib/session.js";
import { FROTA, validarFrota, frotaAleatoria, processarTiro, escolherTiroServidor, TAMANHO } from "../lib/jogo.js";
import * as rotaNew from "../functions/api/game/new.js";
import * as rotaFire from "../functions/api/game/fire.js";
import * as rotaState from "../functions/api/game/state.js";
import * as rotaSurrender from "../functions/api/game/surrender.js";
import * as rotaPlacar from "../functions/api/placar.js";
import * as rotaStatus from "../functions/api/status.js";
import * as rotaMe from "../functions/api/me.js";
import * as rotaDiscord from "../functions/api/auth/discord.js";
import * as rotaCallback from "../functions/api/auth/discord/callback.js";

const RAIZ = join(dirname(fileURLToPath(import.meta.url)), "..");
const SECRET = "segredo-de-teste";

/* ---------- Shim do Cloudflare D1 sobre node:sqlite ---------- */
function criarD1() {
  const db = new DatabaseSync(":memory:");
  for (const arq of readdirSync(join(RAIZ, "migrations")).sort()) {
    db.exec(readFileSync(join(RAIZ, "migrations", arq), "utf8"));
  }
  const stmt = (sql, args = []) => ({
    bind: (...a) => stmt(sql, a),
    first: async () => db.prepare(sql).get(...args) ?? null,
    all: async () => ({ results: db.prepare(sql).all(...args) }),
    run: async () => {
      if (/\bRETURNING\b/i.test(sql)) return { results: db.prepare(sql).all(...args), meta: {} };
      const r = db.prepare(sql).run(...args);
      return { results: [], meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } };
    },
  });
  return {
    _raw: db,
    prepare: (sql) => stmt(sql),
    batch: async (stmts) => {
      db.exec("BEGIN");
      try {
        const out = [];
        for (const s of stmts) out.push(await s.run());
        db.exec("COMMIT");
        return out;
      } catch (e) { db.exec("ROLLBACK"); throw e; }
    },
  };
}

/* ---------- Mini framework de teste ---------- */
let passou = 0, falhou = 0;
async function teste(nome, fn) {
  try { await fn(); passou++; console.log("  ✔ " + nome); }
  catch (e) { falhou++; console.log("  ✘ " + nome + "\n      → " + e.message); }
}
function ok(cond, msg) { if (!cond) throw new Error(msg || "asserção falhou"); }
function igual(a, b, msg) { if (a !== b) throw new Error((msg || "valores diferentes") + `: esperado ${JSON.stringify(b)}, recebido ${JSON.stringify(a)}`); }

async function chamar(rota, metodo, { body, cookie, env, path = "/api/x", rawBody } = {}) {
  const headers = new Headers();
  if (cookie) headers.set("Cookie", cookie);
  if (body !== undefined || rawBody !== undefined) headers.set("Content-Type", "application/json");
  const request = new Request("https://teste.pages.dev" + path, {
    method: metodo,
    headers,
    body: rawBody !== undefined ? rawBody : body !== undefined ? JSON.stringify(body) : undefined,
  });
  const nomeFn = "onRequest" + metodo[0] + metodo.slice(1).toLowerCase();
  const fn = rota[nomeFn] || rota.onRequest;
  const res = await fn({ request, env });
  let dados = null;
  const tipo = res.headers.get("Content-Type") || "";
  if (tipo.includes("json")) dados = await res.json();
  return { status: res.status, dados, headers: res.headers };
}

async function cookieDe(userId, username = "Jogador " + userId) {
  return "discord_session=" + (await signSession({ userId, username, avatar: null }, SECRET));
}

const frotaValida = () => [
  { id: "porta-avioes", linha: 0, coluna: 0, orientacao: "H" },
  { id: "encouracado", linha: 2, coluna: 0, orientacao: "H" },
  { id: "cruzador", linha: 4, coluna: 0, orientacao: "V" },
  { id: "submarino", linha: 4, coluna: 5, orientacao: "V" },
  { id: "destroier", linha: 9, coluna: 8, orientacao: "H" },
];

/* =================================================================== */
console.log("\n1) Regras do jogo (lib/jogo.js)");

await teste("aceita frota válida com os 5 navios", () => ok(validarFrota(frotaValida()).ok));
await teste("rejeita navio ultrapassando a borda (limite 10x10)", () => {
  const f = frotaValida(); f[0].coluna = 6; ok(!validarFrota(f).ok);
});
await teste("rejeita coordenada negativa", () => { const f = frotaValida(); f[4].linha = -1; ok(!validarFrota(f).ok); });
await teste("rejeita coordenada não inteira", () => { const f = frotaValida(); f[4].linha = 1.5; ok(!validarFrota(f).ok); });
await teste("rejeita vertical saindo pela base", () => { const f = frotaValida(); f[2].linha = 8; ok(!validarFrota(f).ok); });
await teste("rejeita sobreposição", () => { const f = frotaValida(); f[1].linha = 0; ok(!validarFrota(f).ok); });
await teste("rejeita navio repetido / faltando", () => { const f = frotaValida(); f[4].id = "porta-avioes"; ok(!validarFrota(f).ok); });
await teste("rejeita orientação inválida", () => { const f = frotaValida(); f[0].orientacao = "D"; ok(!validarFrota(f).ok); });
await teste("rejeita frota com 6 navios", () => { const f = frotaValida(); f.push({ id: "destroier", linha: 7, coluna: 0, orientacao: "H" }); ok(!validarFrota(f).ok); });
await teste("frota aleatória do servidor sempre válida (500 gerações)", () => {
  for (let i = 0; i < 500; i++) {
    const fr = frotaAleatoria();
    const v = validarFrota(fr.map(({ id, linha, coluna, orientacao }) => ({ id, linha, coluna, orientacao })));
    ok(v.ok, v.erro);
  }
});
await teste("tiro: água / acerto / navio afundado", () => {
  const fr = validarFrota(frotaValida()).frota;
  igual(processarTiro(fr, [], 5, 5).resultado, "acerto");
  igual(processarTiro(fr, [], 8, 8).resultado, "água");
  igual(processarTiro(fr, [{ linha: 9, coluna: 8 }], 9, 9).resultado, "navio afundado");
});
await teste("IA do servidor nunca repete coordenada e termina em ≤100 tiros", () => {
  const fr = validarFrota(frotaValida()).frota;
  const tiros = []; const vistos = new Set();
  for (let i = 0; i < 100; i++) {
    const [l, c] = escolherTiroServidor(fr, tiros);
    ok(!vistos.has(l * TAMANHO + c), "repetiu " + l + "," + c);
    vistos.add(l * TAMANHO + c);
    const r = processarTiro(fr, tiros, l, c);
    tiros.push({ linha: l, coluna: c, ...r });
    if (r.fimDeJogo) return;
  }
  throw new Error("IA não terminou");
});

/* =================================================================== */
console.log("\n2) Sessão Discord assinada (lib/session.js)");

await teste("sessão assinada é aceita", async () => {
  const t = await signSession({ userId: "1", username: "a" }, SECRET);
  igual((await verifySession(t, SECRET)).userId, "1");
});
await teste("payload adulterado é rejeitado", async () => {
  const t = await signSession({ userId: "1", username: "a" }, SECRET);
  const [, sig] = t.split(".");
  const falso = Buffer.from(JSON.stringify({ userId: "999", username: "hacker", exp: 9999999999 })).toString("base64url");
  igual(await verifySession(falso + "." + sig, SECRET), null);
});
await teste("assinatura com outro segredo é rejeitada", async () => {
  igual(await verifySession(await signSession({ userId: "1" }, "outro"), SECRET), null);
});
await teste("cookie no formato antigo (base64 sem assinatura) é rejeitado", async () => {
  const antigo = btoa(encodeURIComponent(JSON.stringify({ userId: "1", username: "x" })));
  igual(await verifySession(antigo, SECRET), null);
});

/* =================================================================== */
console.log("\n3) Endpoints serverless + D1 (anti-manipulação)");

const DB = criarD1();
const env = { DB, SESSION_SECRET: SECRET };
const lucas = await cookieDe("111", "Lucas");
const intruso = await cookieDe("222", "Intruso");

for (const [nome, rota, metodo] of [["POST /api/game/new", rotaNew, "POST"], ["POST /api/game/fire", rotaFire, "POST"], ["GET /api/game/state", rotaState, "GET"], ["POST /api/game/surrender", rotaSurrender, "POST"], ["GET /api/me", rotaMe, "GET"]]) {
  await teste(`${nome} sem sessão → 401`, async () => igual((await chamar(rota, metodo, { env, body: metodo === "POST" ? {} : undefined })).status, 401));
}
await teste("cookie forjado (sem assinatura) → 401", async () => {
  const forjado = "discord_session=" + btoa(encodeURIComponent(JSON.stringify({ userId: "111", username: "Lucas" })));
  igual((await chamar(rotaNew, "POST", { env, cookie: forjado, body: { navios: frotaValida() } })).status, 401);
});
await teste("GET /api/me com sessão retorna user_id, username e avatar", async () => {
  const r = await chamar(rotaMe, "GET", { env, cookie: lucas });
  igual(r.status, 200); igual(r.dados.user.userId, "111"); ok("avatar" in r.dados.user);
});
await teste("JSON malformado → 400", async () => igual((await chamar(rotaNew, "POST", { env, cookie: lucas, rawBody: "{oops" })).status, 400));
await teste("frota fora dos limites → 400", async () => {
  const f = frotaValida(); f[0].coluna = 9;
  const r = await chamar(rotaNew, "POST", { env, cookie: lucas, body: { navios: f } });
  igual(r.status, 400); igual(r.dados.error, "frota_invalida");
});
await teste("frota sobreposta → 400", async () => {
  const f = frotaValida(); f[1].linha = 0;
  igual((await chamar(rotaNew, "POST", { env, cookie: lucas, body: { navios: f } })).status, 400);
});

let partidaId;
await teste("frota válida → 201 e resposta NÃO contém a frota do servidor", async () => {
  const r = await chamar(rotaNew, "POST", { env, cookie: lucas, body: { navios: frotaValida() } });
  igual(r.status, 201);
  partidaId = r.dados.partida.id;
  const txt = JSON.stringify(r.dados);
  ok(!txt.includes("frota_servidor") && !txt.includes("frotaServidor"), "vazou frota do servidor");
});
await teste("GET /api/game/state não expõe a frota do servidor", async () => {
  const r = await chamar(rotaState, "GET", { env, cookie: lucas });
  igual(r.status, 200); igual(r.dados.partida.id, partidaId);
  ok(!JSON.stringify(r.dados).includes("frota_servidor"));
});
await teste("disparo fora da malha → 400", async () => igual((await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId, linha: 10, coluna: 0 } })).status, 400));
await teste("disparo com coordenada string → 400", async () => igual((await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId, linha: "1", coluna: 0 } })).status, 400));
await teste("disparo em partida de outro jogador → 403", async () => igual((await chamar(rotaFire, "POST", { env, cookie: intruso, body: { partidaId, linha: 0, coluna: 0 } })).status, 403));
await teste("disparo em partida inexistente → 404", async () => igual((await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId: 99999, linha: 0, coluna: 0 } })).status, 404));

await teste("resposta do disparo é só água/acerto/navio afundado (sem posições inimigas)", async () => {
  const r = await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId, linha: 0, coluna: 0 } });
  igual(r.status, 200);
  ok(["água", "acerto", "navio afundado"].includes(r.dados.resultado));
  const chaves = Object.keys(r.dados).sort().join(",");
  ok(!JSON.stringify(r.dados).includes("navioId"), "vazou navioId");
  ok(!JSON.stringify(r.dados).includes("celulas"), "vazou células: " + chaves);
});
await teste("disparo repetido na mesma coordenada → 409", async () => igual((await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId, linha: 0, coluna: 0 } })).status, 409));

await teste("partida completa: vitória atualiza o placar geral no D1", async () => {
  const linha = DB._raw.prepare("SELECT frota_servidor FROM batalha_partidas WHERE id = ?").get(partidaId);
  const alvos = JSON.parse(linha.frota_servidor).flatMap((n) => n.celulas).filter(([l, c]) => !(l === 0 && c === 0));
  let ultimo;
  for (const [l, c] of alvos) {
    ultimo = await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId, linha: l, coluna: c } });
    if (ultimo.dados.status !== "ativa") break;
  }
  igual(ultimo.dados.status, "vitoria"); igual(ultimo.dados.vencedor, "jogador");
  igual(ultimo.dados.placar.vitorias, 1);
});
await teste("disparo após o fim do confronto → 409", async () => igual((await chamar(rotaFire, "POST", { env, cookie: lucas, body: { partidaId, linha: 9, coluna: 9 } })).status, 409));
await teste("GET /api/placar lista o vencedor", async () => {
  const r = await chamar(rotaPlacar, "GET", { env });
  igual(r.status, 200); igual(r.dados.ranking[0].user_id, "111"); igual(r.dados.ranking[0].vitorias, 1);
});

await teste("derrota: servidor afunda a frota do jogador e registra derrota", async () => {
  const r = await chamar(rotaNew, "POST", { env, cookie: intruso, body: { navios: frotaValida() } });
  const id = r.dados.partida.id;
  let res;
  for (let l = 0; l < 10 && (!res || res.dados.status === "ativa"); l++) {
    for (let c = 0; c < 10; c++) {
      res = await chamar(rotaFire, "POST", { env, cookie: intruso, body: { partidaId: id, linha: l, coluna: c } });
      if (res.status !== 200 || res.dados.status !== "ativa") break;
    }
  }
  igual(res.status, 200);
  ok(["derrota", "vitoria"].includes(res.dados.status));
  const p = DB._raw.prepare("SELECT partidas FROM batalha_placar WHERE user_id = '222'").get();
  igual(p.partidas, 1);
});
await teste("desistir: encerra como derrota; sem partida ativa → 409", async () => {
  await chamar(rotaNew, "POST", { env, cookie: lucas, body: { navios: frotaValida() } });
  const r = await chamar(rotaSurrender, "POST", { env, cookie: lucas });
  igual(r.status, 200); igual(r.dados.placar.derrotas, 1);
  igual((await chamar(rotaSurrender, "POST", { env, cookie: lucas })).status, 409);
});
await teste("controle de concorrência: versão desatualizada não grava", async () => {
  const r = await chamar(rotaNew, "POST", { env, cookie: lucas, body: { navios: frotaValida() } });
  const upd = await DB.prepare("UPDATE batalha_partidas SET status = status WHERE id = ? AND versao = ?").bind(r.dados.partida.id, 999).run();
  igual(upd.meta.changes, 0);
});
await teste("/api/status GET → 200; POST → 405", async () => {
  igual((await chamar(rotaStatus, "GET", { env })).dados.d1Connected, true);
  igual((await chamar(rotaStatus, "POST", { env, body: { conteudo: "x" } })).status, 405);
});
await teste("sem binding D1 → 503 (não quebra)", async () => {
  igual((await chamar(rotaNew, "POST", { env: { SESSION_SECRET: SECRET }, cookie: lucas, body: { navios: frotaValida() } })).status, 503);
});

/* =================================================================== */
console.log("\n4) Discord OAuth2");

await teste("sem credenciais → 503 configured:false", async () => {
  const r = await chamar(rotaDiscord, "GET", { env: {} });
  igual(r.status, 503); igual(r.dados.configured, false);
});
await teste("com credenciais → 302 para discord.com com state e cookie oauth_state", async () => {
  const r = await chamar(rotaDiscord, "GET", { env: { DISCORD_CLIENT_ID: "123", DISCORD_CLIENT_SECRET: "abc" } });
  igual(r.status, 302);
  const loc = new URL(r.headers.get("Location"));
  igual(loc.hostname, "discord.com"); igual(loc.searchParams.get("scope"), "identify");
  ok(loc.searchParams.get("state")); ok(r.headers.get("Set-Cookie").includes("oauth_state=" + loc.searchParams.get("state")));
});
await teste("callback com state inválido é recusado (anti-CSRF)", async () => {
  const r = await chamar(rotaCallback, "GET", { env: { DISCORD_CLIENT_ID: "1", DISCORD_CLIENT_SECRET: "2" }, path: "/api/auth/discord/callback?code=x&state=a", cookie: "oauth_state=b" });
  igual(r.status, 302); ok(r.headers.get("Location").includes("invalid_state"));
});
await teste("callback completo (Discord simulado) grava usuário no D1 e emite sessão assinada", async () => {
  const fetchOriginal = globalThis.fetch;
  globalThis.fetch = async (url) => {
    if (String(url).includes("/oauth2/token")) return Response.json({ access_token: "tok" });
    return Response.json({ id: "80351110224678912", username: "lucas", global_name: "Lucas", avatar: "abc" });
  };
  try {
    const db = criarD1();
    const envCb = { DB: db, DISCORD_CLIENT_ID: "1", DISCORD_CLIENT_SECRET: "segredo" };
    const r = await chamar(rotaCallback, "GET", { env: envCb, path: "/api/auth/discord/callback?code=x&state=s1", cookie: "oauth_state=s1" });
    igual(r.status, 302);
    const sc = r.headers.get("Set-Cookie");
    const token = sc.match(/discord_session=([^;]+)/)[1];
    const sessao = await verifySession(token, "segredo");
    igual(sessao.userId, "80351110224678912"); igual(sessao.username, "Lucas");
    ok(sc.includes("HttpOnly"));
    igual(db._raw.prepare("SELECT username FROM discord_users").get().username, "Lucas");
  } finally { globalThis.fetch = fetchOriginal; }
});

/* =================================================================== */
console.log("\n5) Conformidade de entrega (rubrica)");

function listar(dir) {
  return readdirSync(dir).flatMap((n) => (statSync(join(dir, n)).isDirectory() ? listar(join(dir, n)) : [join(dir, n)]));
}
const publicos = listar(join(RAIZ, "public")).map((f) => readFileSync(f, "utf8")).join("\n");

await teste("sem frameworks proibidos (React/Vue/Angular/Svelte/jQuery)", () => {
  ok(!/\b(react|vue|angular|svelte|jquery)\b/i.test(publicos.replace(/frameworks?/gi, "")), "framework encontrado");
});
await teste("CSS sem text-shadow real e sem drop-shadow em texto", () => {
  const css = readFileSync(join(RAIZ, "public/styles.css"), "utf8");
  for (const m of css.matchAll(/text-shadow\s*:\s*([^;]+);/g)) ok(m[1].trim().startsWith("none"), "text-shadow: " + m[1]);
  ok(!/drop-shadow/.test(css), "drop-shadow encontrado");
});
await teste("rodapé contém a Chave Única", () => {
  const html = readFileSync(join(RAIZ, "public/index.html"), "utf8");
  const footer = html.match(/<footer[\s\S]*?<\/footer>/)[0];
  ok(footer.includes("P26-2B-1768-7598-7D8E-716E"));
});
await teste("licença MIT presente", () => ok(readFileSync(join(RAIZ, "LICENSE"), "utf8").startsWith("MIT License")));
await teste("todas as queries usam prepare/bind (sem concatenação de valores)", () => {
  const funcoes = [...listar(join(RAIZ, "functions")), ...listar(join(RAIZ, "lib"))].map((f) => readFileSync(f, "utf8")).join("\n");
  ok(!/prepare\(\s*`[^`]*\$\{/.test(funcoes), "template string com interpolação em prepare()");
});

/* =================================================================== */
console.log("\n6) Auditoria adversária (Agente 3)");
import * as rotaMiddleware from "../functions/api/_middleware.js";

const DB6 = criarD1();
const env6 = { DB: DB6, SESSION_SECRET: SECRET };
const alice = await cookieDe("601", "Alice");
const bob = await cookieDe("602", "Bob");
const vazou = [];
async function chamar6(rota, metodo, o = {}) {
  const r = await chamar(rota, metodo, { env: env6, ...o });
  const txt = JSON.stringify(r.dados);
  if (/frota_servidor|frotaServidor|celulas|navioId|versao/.test(txt || "")) vazou.push(metodo + " " + txt.slice(0, 120));
  return r;
}
async function assinarManual(payload) {
  const enc = new TextEncoder();
  const corpo = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const key = await crypto.subtle.importKey("raw", enc.encode(SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return "discord_session=" + corpo + "." + Buffer.from(await crypto.subtle.sign("HMAC", key, enc.encode(corpo))).toString("base64url");
}

await teste("sessão expirada (assinatura válida) → 401", async () => {
  igual((await chamar6(rotaMe, "GET", { cookie: await assinarManual({ userId: "601", exp: 1000 }) })).status, 401);
});
await teste("sessão assinada sem userId → 401", async () => {
  igual((await chamar6(rotaMe, "GET", { cookie: await assinarManual({ username: "x", exp: 9999999999 }) })).status, 401);
});
await teste("cookie com 3 partes / lixo base64 / assinatura vazia → 401", async () => {
  const t = alice.split("=")[1];
  for (const c of [t + ".x", "%%%.###", t.split(".")[0] + "."]) igual((await chamar6(rotaMe, "GET", { cookie: "discord_session=" + c })).status, 401, c.slice(0, 20));
});

await teste("POST /api/game/new: 20 payloads hostis → 400 e nenhuma partida criada", async () => {
  const f = frotaValida;
  const troca = (i, campo, v) => f().map((n, k) => (k === i ? { ...n, [campo]: v } : n));
  const casos = [
    { rawBody: "" }, { rawBody: "null" }, { rawBody: "[]" }, { rawBody: "42" }, { body: {} },
    { body: { navios: "abc" } }, { body: { navios: [null, null, null, null, null] } },
    { body: { navios: troca(0, "linha", "0") } }, { body: { navios: troca(0, "linha", 0.5) } },
    { body: { navios: troca(0, "linha", 2 ** 53) } }, { body: { navios: troca(0, "linha", null) } },
    { body: { navios: troca(0, "orientacao", "h") } }, { body: { navios: troca(0, "orientacao", ["H"]) } },
    { body: { navios: troca(0, "id", "' OR 1=1 --") } }, { body: { navios: troca(0, "id", { x: 1 }) } },
    { body: { navios: f().slice(0, 4) } }, { body: { navios: [...f(), f()[4]] } },
    { rawBody: JSON.stringify({ navios: f() }).replace('"linha":0', '"linha":1e309') },
    { rawBody: JSON.stringify({ navios: f() }).replace('"porta-avioes"', '"__proto__"') },
    { body: { navios: f(), lixo: "x".repeat(9000) } },
  ];
  for (const c of casos) igual((await chamar6(rotaNew, "POST", { cookie: alice, ...c })).status, 400, JSON.stringify(c).slice(0, 60));
  igual((await chamar6(rotaState, "GET", { cookie: alice })).dados.partida, null);
});
await teste("células/tamanho forjados no payload são ignorados (servidor recalcula)", async () => {
  const f = frotaValida(); f[0].celulas = [[9, 9]]; f[0].tamanho = 1;
  const r = await chamar6(rotaNew, "POST", { cookie: alice, body: { navios: f } });
  igual(r.status, 201); igual(r.dados.partida.frotaJogador[0].tamanho, 5);
});

let pid6;
await teste("POST /api/game/fire: 17 tipos estranhos → 400", async () => {
  pid6 = (await chamar6(rotaState, "GET", { cookie: alice })).dados.partida.id;
  const casos = [
    { partidaId: pid6, linha: "1", coluna: 1 }, { partidaId: pid6, linha: 1.5, coluna: 1 }, { partidaId: pid6, linha: null, coluna: 1 },
    { partidaId: pid6, linha: [1], coluna: 1 }, { partidaId: pid6, linha: {}, coluna: 1 }, { partidaId: pid6, linha: true, coluna: 1 },
    { partidaId: pid6, linha: 1e20, coluna: 1 }, { partidaId: pid6, linha: 1 }, { partidaId: String(pid6), linha: 1, coluna: 1 },
    { partidaId: pid6 + " OR 1=1", linha: 1, coluna: 1 }, { partidaId: pid6 + 0.5, linha: 1, coluna: 1 }, { partidaId: null, linha: 1, coluna: 1 },
    { linha: 1, coluna: 1 },
  ];
  for (const b of casos) igual((await chamar6(rotaFire, "POST", { cookie: alice, body: b })).status, 400, JSON.stringify(b));
  for (const raw of ["", "{", "[1,2]", "null"]) igual((await chamar6(rotaFire, "POST", { cookie: alice, rawBody: raw })).status, 400, raw);
});
await teste("IDOR: Bob não afeta a partida de Alice (fire 403, surrender 409)", async () => {
  igual((await chamar6(rotaFire, "POST", { cookie: bob, body: { partidaId: pid6, linha: 0, coluna: 0 } })).status, 403);
  igual((await chamar6(rotaSurrender, "POST", { cookie: bob })).status, 409);
  igual((await chamar6(rotaState, "GET", { cookie: alice })).dados.partida.id, pid6);
});
await teste("resposta do tiro tem só ok/resultado/status/tiroServidor/vencedor", async () => {
  const r = await chamar6(rotaFire, "POST", { cookie: alice, body: { partidaId: pid6, linha: 0, coluna: 0 } });
  igual(r.status, 200);
  igual(Object.keys(r.dados).sort().join(","), "ok,resultado,status,tiroServidor,vencedor");
  igual(Object.keys(r.dados.tiroServidor).sort().join(","), "coluna,linha,resultado");
  igual((await chamar6(rotaFire, "POST", { cookie: alice, body: { partidaId: pid6, linha: -0, coluna: 0 } })).status, 409, "-0 repetido");
});
await teste("corrida: 15 tiros simultâneos → tiros gravados = tiros aceitos, sem 5xx", async () => {
  const cel = []; for (let c = 0; c < 10; c++) cel.push([1, c]); for (let c = 0; c < 5; c++) cel.push([3, c]);
  const rs = await Promise.all(cel.map(([l, c]) => chamar6(rotaFire, "POST", { cookie: alice, body: { partidaId: pid6, linha: l, coluna: c } })));
  ok(rs.every((r) => r.status === 200 || r.status === 409), "status inesperado");
  const aceitos = rs.filter((r) => r.status === 200).length;
  const p = (await chamar6(rotaState, "GET", { cookie: alice })).dados.partida;
  igual(p.tirosJogador.length, 1 + aceitos); igual(p.tirosServidor.length, 1 + aceitos);
});
await teste("corrida: último tiro 8x em paralelo → 1 vitória e placar contado 1 vez", async () => {
  const row = DB6._raw.prepare("SELECT frota_servidor, tiros_jogador FROM batalha_partidas WHERE id = ?").get(pid6);
  const feitos = new Set(JSON.parse(row.tiros_jogador).map((t) => t.linha * 10 + t.coluna));
  const alvos = JSON.parse(row.frota_servidor).flatMap((n) => n.celulas).filter(([l, c]) => !feitos.has(l * 10 + c));
  const ultimo = alvos.pop();
  for (const [l, c] of alvos) {
    const r = await chamar6(rotaFire, "POST", { cookie: alice, body: { partidaId: pid6, linha: l, coluna: c } });
    if (r.dados.status !== "ativa") throw new Error("terminou antes: " + r.dados.status);
  }
  const rs = await Promise.all(Array.from({ length: 8 }, () => chamar6(rotaFire, "POST", { cookie: alice, body: { partidaId: pid6, linha: ultimo[0], coluna: ultimo[1] } })));
  igual(rs.filter((r) => r.status === 200 && r.dados.status === "vitoria").length, 1, "vitórias");
  const p = DB6._raw.prepare("SELECT vitorias, partidas FROM batalha_placar WHERE user_id = '601'").get();
  igual(p.vitorias, 1); igual(p.partidas, 1);
});
await teste("corrida: 10x POST /api/game/new simultâneos → 1 ativa e derrotas = abandonadas", async () => {
  for (let rodada = 0; rodada < 2; rodada++) {
    const rs = await Promise.all(Array.from({ length: 10 }, () => chamar6(rotaNew, "POST", { cookie: bob, body: { navios: frotaValida() } })));
    ok(rs.every((r) => r.status === 201 || r.status === 409), "status: " + rs.map((r) => r.status));
    const q = (s) => DB6._raw.prepare("SELECT COUNT(*) n FROM batalha_partidas WHERE user_id = '602' AND status = ?").get(s).n;
    igual(q("ativa"), 1, "ativas");
    const pb = DB6._raw.prepare("SELECT derrotas FROM batalha_placar WHERE user_id = '602'").get();
    igual(pb ? pb.derrotas : 0, q("abandonada"), "derrotas x abandonadas");
  }
});
await teste("placar condicionado a changes(): UPDATE que não altera nada não conta", async () => {
  const { registrarFimDePartida } = await import("../lib/placar.js");
  const u = { userId: "699", username: "Z", avatar: null };
  await DB6.batch([DB6.prepare("UPDATE batalha_partidas SET status = status WHERE id = -1"), registrarFimDePartida(DB6, u, true, [], { seAlterou: true })]);
  igual(DB6._raw.prepare("SELECT COUNT(*) n FROM batalha_placar WHERE user_id = '699'").get().n, 0);
});
await teste("username malicioso (SQLi) é gravado como texto; tabela intacta", async () => {
  const evil = await cookieDe("603", "Robert'); DROP TABLE batalha_placar;--");
  igual((await chamar6(rotaNew, "POST", { cookie: evil, body: { navios: frotaValida() } })).status, 201);
  igual((await chamar6(rotaSurrender, "POST", { cookie: evil })).status, 200);
  ok((await chamar6(rotaPlacar, "GET", {})).dados.ranking.some((j) => j.username.startsWith("Robert')")));
});
await teste("_middleware: exceção vira 500 JSON sem detalhes internos", async () => {
  const errOriginal = console.error; console.error = () => {};
  const res = await rotaMiddleware.onRequest({ request: new Request("https://t.pages.dev/api/x"), next: async () => { throw new Error("SELECT segredo FROM x"); } });
  console.error = errOriginal;
  igual(res.status, 500);
  const txt = await res.text();
  ok(!txt.includes("segredo") && JSON.parse(txt).error === "erro_interno", txt);
});
await teste("DDL do ensureSchema (sem migrações) é SQL válido e cria o índice único parcial", () => {
  const cru = new DatabaseSync(":memory:");
  const src = readFileSync(join(RAIZ, "lib/session.js"), "utf8");
  for (const m of src.matchAll(/"(CREATE [^"]+)"/g)) cru.exec(m[1]);
  ok(cru.prepare("SELECT name FROM sqlite_master WHERE name = 'idx_batalha_partidas_uma_ativa'").get(), "índice único parcial ausente");
});
await teste("nenhuma resposta desta seção vazou a matriz do oponente", () => ok(vazou.length === 0, vazou.join(" | ")));

/* =================================================================== */
console.log("\n7) Reteste rodada 2 (Agente 3): método errado → 405 JSON com Allow");
import * as rotaLogout from "../functions/api/auth/logout.js";
{
  const soPost = [["/api/game/new", rotaNew], ["/api/game/fire", rotaFire], ["/api/game/surrender", rotaSurrender], ["/api/auth/logout", rotaLogout]];
  const soGet = [["/api/game/state", rotaState], ["/api/placar", rotaPlacar], ["/api/me", rotaMe], ["/api/status", rotaStatus], ["/api/auth/discord", rotaDiscord], ["/api/auth/discord/callback", rotaCallback]];
  for (const [nome, rota, permitido, errados] of [
    ...soPost.map(([n, r]) => [n, r, "POST", ["GET", "PUT", "DELETE", "PATCH"]]),
    ...soGet.map(([n, r]) => [n, r, "GET", ["POST", "PUT", "DELETE", "PATCH"]]),
  ]) {
    await teste(`${nome}: ${errados.join("/")} → 405 JSON, Allow: ${permitido}`, async () => {
      ok(typeof rota["onRequest" + permitido[0] + permitido.slice(1).toLowerCase()] === "function", "handler do método certo ausente");
      for (const m of errados) {
        const r = await chamar(rota, m, { env: env6, cookie: alice, body: m === "GET" ? undefined : { navios: frotaValida() } });
        igual(r.status, 405, m);
        igual(r.headers.get("Allow"), permitido, m + " Allow");
        ok(r.dados && r.dados.ok === false && r.dados.error === "method_not_allowed", m + " corpo JSON");
      }
    });
  }
  await teste("métodos errados não criaram/alteraram partidas", async () => {
    const antes = DB6._raw.prepare("SELECT COUNT(*) n, SUM(versao) v FROM batalha_partidas").get();
    await chamar(rotaNew, "GET", { env: env6, cookie: alice });
    await chamar(rotaSurrender, "DELETE", { env: env6, cookie: bob });
    const depois = DB6._raw.prepare("SELECT COUNT(*) n, SUM(versao) v FROM batalha_partidas").get();
    igual(depois.n, antes.n); igual(depois.v, antes.v);
  });
  await teste("ensureSchema tem o mesmo CHECK de status da migração 0002", () => {
    const cru = new DatabaseSync(":memory:");
    const src = readFileSync(join(RAIZ, "lib/session.js"), "utf8");
    for (const m of src.matchAll(/"(CREATE [^"]+)"/g)) cru.exec(m[1]);
    let recusou = false;
    try { cru.prepare("INSERT INTO batalha_partidas (user_id, status, frota_jogador, frota_servidor) VALUES ('x', 'hackeado', '[]', '[]')").run(); } catch { recusou = true; }
    ok(recusou, "status fora da lista foi aceito");
  });
}

console.log(`\nResultado: ${passou} aprovados, ${falhou} reprovados.\n`);
process.exit(falhou ? 1 : 0);
