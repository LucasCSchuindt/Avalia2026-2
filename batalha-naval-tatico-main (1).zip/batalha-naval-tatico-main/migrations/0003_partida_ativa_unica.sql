-- Projeto #3 Batalha Naval Tático (P26-2B-1768-7598-7D8E-716E)
-- Garante no banco que cada jogador tem no máximo UMA partida ativa
-- (evita partidas duplicadas quando dois POST /api/game/new chegam ao mesmo tempo).

-- Limpeza de eventuais duplicatas antigas: mantém só a partida ativa mais recente.
UPDATE batalha_partidas
SET status = 'abandonada', finished_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP, versao = versao + 1
WHERE status = 'ativa'
  AND id NOT IN (SELECT MAX(id) FROM batalha_partidas WHERE status = 'ativa' GROUP BY user_id);

CREATE UNIQUE INDEX IF NOT EXISTS idx_batalha_partidas_uma_ativa
  ON batalha_partidas(user_id) WHERE status = 'ativa';
