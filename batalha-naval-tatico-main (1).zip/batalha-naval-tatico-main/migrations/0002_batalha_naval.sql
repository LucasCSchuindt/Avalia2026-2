-- Projeto #3 Batalha Naval Tático (P26-2B-1768-7598-7D8E-716E)
-- Partidas: as frotas ficam em JSON; a frota do servidor NUNCA é enviada ao cliente.
CREATE TABLE IF NOT EXISTS batalha_partidas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativa' CHECK (status IN ('ativa', 'vitoria', 'derrota', 'abandonada')),
  frota_jogador TEXT NOT NULL,
  frota_servidor TEXT NOT NULL,
  tiros_jogador TEXT NOT NULL DEFAULT '[]',
  tiros_servidor TEXT NOT NULL DEFAULT '[]',
  versao INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finished_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_batalha_partidas_user_status ON batalha_partidas(user_id, status);

-- Placar geral, atualizado pelo servidor ao término de cada confronto.
CREATE TABLE IF NOT EXISTS batalha_placar (
  user_id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  avatar TEXT,
  vitorias INTEGER NOT NULL DEFAULT 0,
  derrotas INTEGER NOT NULL DEFAULT 0,
  partidas INTEGER NOT NULL DEFAULT 0,
  tiros_total INTEGER NOT NULL DEFAULT 0,
  acertos_total INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_batalha_placar_vitorias ON batalha_placar(vitorias DESC);
