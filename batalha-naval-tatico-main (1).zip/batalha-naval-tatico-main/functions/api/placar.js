/**
 * Cloudflare Pages Function — GET /api/placar
 * Ranking geral (top 10) do Cloudflare D1. Público, somente leitura.
 */
import { ensureSchema, erro, json, metodoNaoPermitido } from "../../lib/session.js";

export async function onRequestGet(context) {
  const { env } = context;
  if (!env.DB) return erro(503, "d1_indisponivel", "Banco Cloudflare D1 não vinculado (binding DB).");

  await ensureSchema(env.DB);
  const { results } = await env.DB.prepare(
    "SELECT user_id, username, avatar, vitorias, derrotas, partidas, tiros_total, acertos_total FROM batalha_placar " +
    "ORDER BY vitorias DESC, (CAST(acertos_total AS REAL) / MAX(tiros_total, 1)) DESC, partidas ASC LIMIT 10"
  ).all();

  return json({ ok: true, ranking: results || [] });
}

/** Qualquer outro método → 405 JSON (onRequestGet tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("GET");
}
