/**
 * Middleware das Cloudflare Pages Functions em /api/*.
 * Qualquer exceção não tratada (ex.: falha temporária do D1) vira um JSON 500
 * padronizado, sem expor stack trace nem detalhes internos ao cliente.
 */
import { erro } from "../../lib/session.js";

export async function onRequest(context) {
  try {
    return await context.next();
  } catch (e) {
    console.error("Erro não tratado em", new URL(context.request.url).pathname, e);
    return erro(500, "erro_interno", "Erro interno do servidor. Tente novamente.");
  }
}
