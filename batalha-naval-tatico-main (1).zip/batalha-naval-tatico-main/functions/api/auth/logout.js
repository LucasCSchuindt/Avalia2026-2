/**
 * Cloudflare Pages Function — POST /api/auth/logout
 * Encerra a sessão apagando o cookie HttpOnly.
 */
import { json, SESSION_COOKIE, metodoNaoPermitido } from "../../../lib/session.js";

export async function onRequestPost() {
  return json({ ok: true }, 200, {
    "Set-Cookie": `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`,
  });
}

/** Qualquer outro método → 405 JSON (onRequestPost tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("POST");
}
