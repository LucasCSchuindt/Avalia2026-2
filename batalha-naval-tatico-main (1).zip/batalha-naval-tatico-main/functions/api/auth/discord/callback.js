/**
 * Cloudflare Pages Function — GET /api/auth/discord/callback
 * 1. Confere o "state" (anti-CSRF).
 * 2. Troca o authorization code pelo access token do Discord.
 * 3. Busca o perfil (/users/@me): user_id, username e avatar.
 * 4. Persiste o usuário no Cloudflare D1.
 * 5. Emite cookie de sessão HttpOnly ASSINADO (HMAC-SHA256).
 */
import { ensureSchema, getCookie, getSessionSecret, signSession, SESSION_COOKIE, SESSION_MAX_AGE, metodoNaoPermitido } from "../../../../lib/session.js";

function voltar(origin, erro) {
  return new Response(null, {
    status: 302,
    headers: {
      Location: new URL("/?auth_error=" + encodeURIComponent(erro), origin).href,
      "Set-Cookie": "oauth_state=; Path=/api/auth; HttpOnly; Secure; SameSite=Lax; Max-Age=0",
      "Cache-Control": "no-store",
    },
  });
}

export async function onRequestGet(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  if (error || !code) return voltar(url.origin, error || "missing_code");

  const stateCookie = getCookie(request, "oauth_state");
  if (!state || !stateCookie || state !== stateCookie) return voltar(url.origin, "invalid_state");

  const secret = getSessionSecret(env);
  if (!env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET || !secret) {
    return voltar(url.origin, "missing_credentials");
  }

  const redirectUri = new URL("/api/auth/discord/callback", url.origin).href;

  try {
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: env.DISCORD_CLIENT_ID,
        client_secret: env.DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    });
    if (!tokenRes.ok) return voltar(url.origin, "token_exchange_failed");

    const tokenData = await tokenRes.json();
    const userRes = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    if (!userRes.ok) return voltar(url.origin, "fetch_user_failed");

    const discordUser = await userRes.json();
    const userId = String(discordUser.id);
    const username = String(discordUser.global_name || discordUser.username || "Jogador").slice(0, 80);
    const avatar = discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${userId}/${discordUser.avatar}.png?size=64`
      : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(userId) >> 22n) % 6}.png`;

    if (env.DB) {
      await ensureSchema(env.DB);
      await env.DB.prepare(
        "INSERT INTO discord_users (user_id, username, avatar, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP) " +
        "ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, avatar = excluded.avatar, updated_at = CURRENT_TIMESTAMP"
      ).bind(userId, username, avatar).run();
    }

    const token = await signSession({ userId, username, avatar }, secret);
    const headers = new Headers({ Location: "/?login=success", "Cache-Control": "no-store" });
    headers.append("Set-Cookie", `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${SESSION_MAX_AGE}`);
    headers.append("Set-Cookie", "oauth_state=; Path=/api/auth; HttpOnly; Secure; SameSite=Lax; Max-Age=0");
    return new Response(null, { status: 302, headers });
  } catch {
    return voltar(url.origin, "exception");
  }
}

/** Qualquer outro método → 405 JSON (onRequestGet tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("GET");
}
