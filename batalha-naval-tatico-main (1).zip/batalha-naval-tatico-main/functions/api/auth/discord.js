/**
 * Cloudflare Pages Function — GET /api/auth/discord
 * Inicia o fluxo OAuth2 do Discord (escopo "identify": user_id, username e avatar).
 * Gera um "state" aleatório guardado em cookie HttpOnly para proteger contra CSRF.
 */
import { json, metodoNaoPermitido } from "../../../lib/session.js";

export async function onRequestGet(context) {
  const { request, env } = context;
  const url = new URL(request.url);

  if (!env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET) {
    return json({
      ok: false,
      configured: false,
      message: "Defina DISCORD_CLIENT_ID e DISCORD_CLIENT_SECRET nas variáveis do Cloudflare Pages (Settings → Environment variables).",
    }, 503);
  }

  const state = crypto.randomUUID();
  const redirectUri = new URL("/api/auth/discord/callback", url.origin).href;
  const authorizeUrl = new URL("https://discord.com/oauth2/authorize");
  authorizeUrl.searchParams.set("client_id", env.DISCORD_CLIENT_ID);
  authorizeUrl.searchParams.set("redirect_uri", redirectUri);
  authorizeUrl.searchParams.set("response_type", "code");
  authorizeUrl.searchParams.set("scope", "identify");
  authorizeUrl.searchParams.set("state", state);

  return new Response(null, {
    status: 302,
    headers: {
      Location: authorizeUrl.href,
      "Set-Cookie": `oauth_state=${state}; Path=/api/auth; HttpOnly; Secure; SameSite=Lax; Max-Age=600`,
      "Cache-Control": "no-store",
    },
  });
}

/** Qualquer outro método → 405 JSON (onRequestGet tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("GET");
}
