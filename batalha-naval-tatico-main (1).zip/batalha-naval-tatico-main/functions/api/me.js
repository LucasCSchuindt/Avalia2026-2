/**
 * Cloudflare Pages Function — GET /api/me
 * Retorna o perfil Discord da sessão (user_id, username, avatar) ou 401.
 */
import { getSessionUser, json, metodoNaoPermitido } from "../../lib/session.js";

export async function onRequestGet(context) {
  const { request, env } = context;
  const user = await getSessionUser(request, env);
  if (!user) {
    return json({
      ok: false,
      autenticado: false,
      discordConfigurado: Boolean(env.DISCORD_CLIENT_ID && env.DISCORD_CLIENT_SECRET),
    }, 401);
  }
  return json({ ok: true, autenticado: true, user });
}

/** Qualquer outro método → 405 JSON (onRequestGet tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("GET");
}
