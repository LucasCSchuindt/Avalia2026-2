/**
 * Cloudflare Pages Function — POST /api/game/new
 * Fase 1 (posicionamento): recebe a frota do jogador, VALIDA no servidor
 * (5 navios oficiais, dentro da malha 10x10, sem sobreposição), gera a frota
 * secreta do servidor e cria a partida no Cloudflare D1.
 * Se já houver partida ativa, ela é encerrada como derrota (abandono).
 */
import { ensureSchema, erro, getSessionUser, json, lerJson, metodoNaoPermitido } from "../../../lib/session.js";
import { frotaAleatoria, validarFrota, visaoPublica } from "../../../lib/jogo.js";
import { placarDoUsuario, registrarFimDePartida } from "../../../lib/placar.js";

export async function onRequestPost(context) {
  const { request, env } = context;

  const user = await getSessionUser(request, env);
  if (!user) return erro(401, "nao_autenticado", "Entre com o Discord para jogar.");
  if (!env.DB) return erro(503, "d1_indisponivel", "Banco Cloudflare D1 não vinculado (binding DB).");

  const body = await lerJson(request);
  if (!body) return erro(400, "json_invalido", "Corpo da requisição deve ser um JSON válido.");

  const validacao = validarFrota(body.navios);
  if (!validacao.ok) return erro(400, "frota_invalida", validacao.erro);

  await ensureSchema(env.DB);

  const ativa = await env.DB.prepare(
    "SELECT id, tiros_jogador FROM batalha_partidas WHERE user_id = ? AND status = 'ativa'"
  ).bind(user.userId).first();

  const ops = [];
  if (ativa) {
    ops.push(env.DB.prepare(
      "UPDATE batalha_partidas SET status = 'abandonada', finished_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP, versao = versao + 1 WHERE id = ? AND status = 'ativa'"
    ).bind(ativa.id));
    // Só conta a derrota se ESTE batch encerrou a partida (uma requisição concorrente
    // pode tê-la encerrado entre o SELECT e o batch — ex.: último tiro numa vitória).
    ops.push(registrarFimDePartida(env.DB, user, false, JSON.parse(ativa.tiros_jogador), { seAlterou: true }));
  }
  ops.push(env.DB.prepare(
    "INSERT INTO batalha_partidas (user_id, status, frota_jogador, frota_servidor) VALUES (?, 'ativa', ?, ?) RETURNING *"
  ).bind(user.userId, JSON.stringify(validacao.frota), JSON.stringify(frotaAleatoria())));

  let resultados;
  try {
    resultados = await env.DB.batch(ops);
  } catch (e) {
    // Índice único parcial (1 partida ativa por jogador): outra requisição criou a partida antes.
    if (/UNIQUE/i.test(String(e && e.message))) {
      return erro(409, "conflito", "Outra partida foi criada ao mesmo tempo. Recarregue e tente novamente.");
    }
    throw e;
  }
  const partida = resultados[resultados.length - 1].results[0];

  return json({
    ok: true,
    partida: visaoPublica(partida),
    placar: await placarDoUsuario(env.DB, user.userId),
  }, 201);
}

/** Qualquer outro método → 405 JSON (onRequestPost tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("POST");
}
