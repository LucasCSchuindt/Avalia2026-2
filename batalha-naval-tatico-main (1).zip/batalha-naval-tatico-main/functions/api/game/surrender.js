/**
 * Cloudflare Pages Function — POST /api/game/surrender
 * Encerra a partida ativa do jogador como derrota e atualiza o placar.
 */
import { ensureSchema, erro, getSessionUser, json, metodoNaoPermitido } from "../../../lib/session.js";
import { placarDoUsuario, registrarFimDePartida } from "../../../lib/placar.js";

export async function onRequestPost(context) {
  const { request, env } = context;

  const user = await getSessionUser(request, env);
  if (!user) return erro(401, "nao_autenticado", "Entre com o Discord para jogar.");
  if (!env.DB) return erro(503, "d1_indisponivel", "Banco Cloudflare D1 não vinculado (binding DB).");

  await ensureSchema(env.DB);
  const ativa = await env.DB.prepare(
    "SELECT id, versao, tiros_jogador FROM batalha_partidas WHERE user_id = ? AND status = 'ativa' ORDER BY id DESC LIMIT 1"
  ).bind(user.userId).first();
  if (!ativa) return erro(409, "sem_partida_ativa", "Você não tem partida ativa.");

  // Encerramento + placar na mesma transação; o placar só conta se o UPDATE venceu a corrida.
  const [upd] = await env.DB.batch([
    env.DB.prepare(
      "UPDATE batalha_partidas SET status = 'abandonada', finished_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP, versao = versao + 1 WHERE id = ? AND versao = ? AND status = 'ativa'"
    ).bind(ativa.id, ativa.versao),
    registrarFimDePartida(env.DB, user, false, JSON.parse(ativa.tiros_jogador), { seAlterou: true }),
  ]);
  if (!upd.meta || upd.meta.changes !== 1) return erro(409, "conflito", "A partida foi atualizada por outra requisição.");
  return json({ ok: true, status: "abandonada", placar: await placarDoUsuario(env.DB, user.userId) });
}

/** Qualquer outro método → 405 JSON (onRequestPost tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("POST");
}
