/**
 * Cloudflare Pages Function — POST /api/game/fire
 * Fase 2 (combate): processa o bombardeio do jogador contra a matriz OCULTA do servidor.
 * Ao cliente retorna apenas "água", "acerto" ou "navio afundado" — nunca as posições inimigas.
 * Em seguida o servidor dispara de volta contra a frota do jogador.
 * Ao término do confronto, atualiza o placar geral no D1.
 */
import { ensureSchema, erro, getSessionUser, json, lerJson, metodoNaoPermitido } from "../../../lib/session.js";
import { dentroDaMalha, escolherTiroServidor, processarTiro } from "../../../lib/jogo.js";
import { placarDoUsuario, registrarFimDePartida } from "../../../lib/placar.js";

export async function onRequestPost(context) {
  const { request, env } = context;

  const user = await getSessionUser(request, env);
  if (!user) return erro(401, "nao_autenticado", "Entre com o Discord para jogar.");
  if (!env.DB) return erro(503, "d1_indisponivel", "Banco Cloudflare D1 não vinculado (binding DB).");

  const body = await lerJson(request);
  if (!body) return erro(400, "json_invalido", "Corpo da requisição deve ser um JSON válido.");

  const { partidaId, linha, coluna } = body;
  if (!Number.isInteger(partidaId)) return erro(400, "partida_invalida", "partidaId deve ser um número inteiro.");
  if (!dentroDaMalha(linha, coluna)) return erro(400, "coordenada_invalida", "Coordenada fora da malha 10x10.");

  await ensureSchema(env.DB);

  const partida = await env.DB.prepare("SELECT * FROM batalha_partidas WHERE id = ?").bind(partidaId).first();
  if (!partida) return erro(404, "partida_nao_encontrada", "Partida não encontrada.");
  if (partida.user_id !== user.userId) return erro(403, "acesso_negado", "Esta partida pertence a outro jogador.");
  if (partida.status !== "ativa") return erro(409, "partida_encerrada", "Esta partida já terminou.");

  const tirosJogador = JSON.parse(partida.tiros_jogador);
  if (tirosJogador.some((t) => t.linha === linha && t.coluna === coluna)) {
    return erro(409, "tiro_repetido", "Você já bombardeou essa coordenada.");
  }

  // 1) Tiro do jogador contra a frota oculta do servidor
  const frotaServidor = JSON.parse(partida.frota_servidor);
  const tiro = processarTiro(frotaServidor, tirosJogador, linha, coluna);
  tirosJogador.push({ linha, coluna, resultado: tiro.resultado, navioId: tiro.navioId });

  let status = "ativa";
  let tiroServidor = null;
  const tirosServidor = JSON.parse(partida.tiros_servidor);

  if (tiro.fimDeJogo) {
    status = "vitoria";
  } else {
    // 2) Contra-ataque do servidor
    const frotaJogador = JSON.parse(partida.frota_jogador);
    const [l, c] = escolherTiroServidor(frotaJogador, tirosServidor);
    const r = processarTiro(frotaJogador, tirosServidor, l, c);
    tirosServidor.push({ linha: l, coluna: c, resultado: r.resultado, navioId: r.navioId });
    tiroServidor = { linha: l, coluna: c, resultado: r.resultado };
    if (r.fimDeJogo) status = "derrota";
  }

  // 3) Grava com controle de versão (evita dois disparos simultâneos na mesma jogada).
  //    Se o confronto terminou, o placar entra na MESMA transação (batch) e só é
  //    gravado se o UPDATE acima venceu a corrida (changes() = 1).
  const update = env.DB.prepare(
    "UPDATE batalha_partidas SET tiros_jogador = ?, tiros_servidor = ?, status = ?, versao = versao + 1, updated_at = CURRENT_TIMESTAMP, " +
    "finished_at = CASE WHEN ? <> 'ativa' THEN CURRENT_TIMESTAMP ELSE finished_at END WHERE id = ? AND versao = ? AND status = 'ativa'"
  ).bind(JSON.stringify(tirosJogador), JSON.stringify(tirosServidor), status, status, partida.id, partida.versao);

  const resultadoUpdate = status === "ativa"
    ? await update.run()
    : (await env.DB.batch([update, registrarFimDePartida(env.DB, user, status === "vitoria", tirosJogador, { seAlterou: true })]))[0];
  if (!resultadoUpdate.meta || resultadoUpdate.meta.changes !== 1) {
    return erro(409, "conflito", "A partida foi atualizada por outra requisição. Recarregue e tente novamente.");
  }

  return json({
    ok: true,
    resultado: tiro.resultado,
    tiroServidor,
    status,
    vencedor: status === "vitoria" ? "jogador" : status === "derrota" ? "servidor" : null,
    placar: status !== "ativa" ? await placarDoUsuario(env.DB, user.userId) : undefined,
  });
}

/** Qualquer outro método → 405 JSON (onRequestPost tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("POST");
}
