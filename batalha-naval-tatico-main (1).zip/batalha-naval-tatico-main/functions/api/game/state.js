/**
 * Cloudflare Pages Function — GET /api/game/state
 * Retorna a partida ativa do jogador autenticado (sem a frota do servidor) e o placar dele.
 */
import { ensureSchema, erro, getSessionUser, json, metodoNaoPermitido } from "../../../lib/session.js";
import { visaoPublica } from "../../../lib/jogo.js";
import { placarDoUsuario } from "../../../lib/placar.js";

export async function onRequestGet(context) {
  const { request, env } = context;

  const user = await getSessionUser(request, env);
  if (!user) return erro(401, "nao_autenticado", "Entre com o Discord para jogar.");
  if (!env.DB) return erro(503, "d1_indisponivel", "Banco Cloudflare D1 não vinculado (binding DB).");

  await ensureSchema(env.DB);
  const partida = await env.DB.prepare(
    "SELECT * FROM batalha_partidas WHERE user_id = ? AND status = 'ativa' ORDER BY id DESC LIMIT 1"
  ).bind(user.userId).first();

  return json({
    ok: true,
    user,
    partida: partida ? visaoPublica(partida) : null,
    placar: await placarDoUsuario(env.DB, user.userId),
  });
}

/** Qualquer outro método → 405 JSON (onRequestGet tem precedência). */
export async function onRequest() {
  return metodoNaoPermitido("GET");
}
