/**
 * Cloudflare Pages Function — /api/status
 * GET: diagnóstico (conectividade D1, OAuth2 configurado, sessão atual, totais do jogo).
 * Somente leitura — não expõe dados de partidas.
 */
import { CHAVE_PROJETO, ensureSchema, getSessionUser, json } from "../../lib/session.js";

export async function onRequestGet(context) {
  const { request, env } = context;
  const sessionUser = await getSessionUser(request, env);

  let d1Connected = false;
  let totalPartidas = 0;
  let totalJogadores = 0;

  if (env.DB) {
    try {
      await ensureSchema(env.DB);
      const p = await env.DB.prepare("SELECT COUNT(*) AS total FROM batalha_partidas").first();
      const j = await env.DB.prepare("SELECT COUNT(*) AS total FROM batalha_placar").first();
      totalPartidas = Number(p?.total || 0);
      totalJogadores = Number(j?.total || 0);
      d1Connected = true;
    } catch {
      d1Connected = false;
    }
  }

  return json({
    ok: true,
    chave: CHAVE_PROJETO,
    projectId: 3,
    projectTitle: "Batalha Naval Tático",
    d1Connected,
    discordOAuthConfigured: Boolean(env.DISCORD_CLIENT_ID && env.DISCORD_CLIENT_SECRET),
    sessionUser,
    totalPartidas,
    totalJogadores,
    serverTimestamp: new Date().toISOString(),
  });
}

export async function onRequest() {
  return json({ ok: false, error: "method_not_allowed" }, 405, { Allow: "GET" });
}
