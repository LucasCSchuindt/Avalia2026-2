# Projeto #3: Batalha Naval Tático

- **Modalidade:** Projeto Oficial Sorteado (Valendo 100 pontos)
- **Estudante:** Lucas Carneiro Schuindt
- **Turma:** 2B
- **Chave Única:** `P26-2B-1768-7598-7D8E-716E`
- **URL_CLOUDFLARE:** `https://p26-2b-1768-7598-7d8e-716e.pages.dev` *(Atualize com a URL pública real do seu deploy na Cloudflare antes de abrir o Pull Request)*

---

## Especificação do Projeto

Implemente o clássico jogo de Batalha Naval em duas fases: posicionamento da frota em uma malha 10x10 e combate por coordenadas. O cliente em JavaScript vanilla deve gerenciar a interação de posicionamento horizontal e vertical das embarcações e disparar requisições fetch para o backend na Cloudflare a cada bombardeio realizado.

A autenticação via Discord OAuth2 vincula cada jogador às suas partidas ativas no Cloudflare D1. As funções serverless devem validar se as embarcações foram posicionadas dentro dos limites da matriz e processar os disparos ocultando a matriz do oponente, retornando ao cliente apenas se o tiro resultou em "água", "acerto" ou "navio afundado", atualizando o placar geral ao término do confronto.

---

## Como Jogar

1. **Entre com o Discord** (botão no topo). O cabeçalho passa a exibir seu avatar, nome e `user_id`.
2. **Fase 1 — Posicionamento:** escolha um navio (Porta-aviões 5, Encouraçado 4, Cruzador 3, Submarino 3, Destróier 2), defina a orientação (botão ou tecla `R`) e clique na sua malha. A pré-visualização fica verde (válida) ou vermelha (inválida). Clique num navio já posicionado para movê-lo, ou use "Posicionar aleatório".
3. Clique em **Iniciar batalha**: a frota é enviada para `POST /api/game/new` e **validada no servidor** (5 navios, dentro da malha 10x10, sem sobreposição).
4. **Fase 2 — Combate:** cada clique na malha inimiga faz um `fetch` para `POST /api/game/fire`. O servidor responde apenas `água`, `acerto` ou `navio afundado` e contra-ataca na sua frota.
5. Ao afundar todos os navios (ou perder os seus), o **placar geral** é atualizado no Cloudflare D1.

## Arquitetura

```
P26-2B-1768-7598-7D8E-716E/
├── public/                 # Interface (HTML5 + CSS3 + Vanilla JS, sem frameworks)
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── functions/api/          # Cloudflare Pages Functions (toda a regra de negócio)
│   ├── _middleware.js              erros inesperados viram JSON 500 (sem detalhes internos)
│   ├── auth/discord.js             GET  inicia OAuth2 (com state anti-CSRF)
│   ├── auth/discord/callback.js    GET  troca code → token → perfil, grava no D1, cookie assinado
│   ├── auth/logout.js              POST encerra a sessão
│   ├── me.js                       GET  perfil da sessão (401 se não autenticado)
│   ├── game/new.js                 POST valida frota e cria partida
│   ├── game/fire.js                POST processa disparo + contra-ataque do servidor
│   ├── game/state.js               GET  partida ativa (sem a frota inimiga)
│   ├── game/surrender.js           POST desistir (conta como derrota)
│   ├── placar.js                   GET  ranking geral (top 10)
│   └── status.js                   GET  diagnóstico (D1 / OAuth2)
├── lib/                    # Módulos compartilhados do servidor
│   ├── jogo.js             # Regras: validação da frota, disparos, IA do oponente
│   ├── placar.js           # Atualização do placar geral
│   └── session.js          # Sessão HMAC-SHA256, helpers JSON, esquema D1
├── migrations/             # Esquema do Cloudflare D1 (0001 base, 0002 jogo, 0003 1 partida ativa por jogador)
├── tests/teste-api.mjs     # Bateria do Agente de Teste e Validação
├── docs/agentes/           # Relatórios dos 3 agentes
└── skills/                 # Skills dos agentes (ver AGENTS.md)
```

### Segurança

- **Matriz do oponente oculta:** a frota do servidor fica só no D1 e nunca aparece em nenhuma resposta da API.
- **Sessão assinada:** o cookie `discord_session` é `HttpOnly` e assinado com HMAC-SHA256. Alterar `user_id` no cliente invalida a sessão (401).
- **Anti-manipulação:** `400` para payload inválido/coordenada fora da malha, `401` sem sessão, `403` ao atirar na partida de outro jogador, `409` para tiro repetido, partida encerrada ou disparos simultâneos (controle por versão).
- **SQL parametrizado:** todas as queries usam `env.DB.prepare(...).bind(...)`.
- **OAuth2 com `state`:** protege o login contra CSRF.

## Testes

Na subpasta do projeto (Node 22+):

```powershell
node tests/teste-api.mjs
```

Executa as Functions reais contra um SQLite em memória que imita o D1: regras do jogo, sessão assinada, todos os códigos HTTP de anti-manipulação, partida completa (vitória e derrota), OAuth2 e conformidade com a rubrica.

---

## Como Publicar esta Subpasta no Cloudflare Pages + D1 + Discord OAuth2

1. No painel da Cloudflare (**Workers & Pages** → **Create** → **Pages** → **Connect to Git**), selecione o seu fork do repositório `Avalia2026-2`.
2. Configure os parâmetros de build apontando para esta subpasta:
   - **Root directory (Diretório raiz):** `P26-2B-1768-7598-7D8E-716E`
   - **Build command:** *(deixe em branco — HTML/CSS/JS puro)*
   - **Build output directory:** `public`
3. Crie o banco de dados D1 e aplique as migrações (no terminal do laboratório usando Scoop):
   ```powershell
   cd P26-2B-1768-7598-7D8E-716E
   npx.cmd wrangler d1 create db-p26-2b-1768-7598-7d8e-716e
   # Copie o database_id gerado para o arquivo wrangler.jsonc e execute:
   npx.cmd wrangler d1 migrations apply DB --remote
   ```
4. **Vincule o Banco D1 ao seu Cloudflare Pages (Obrigatório para ativar env.DB):**
   - ⚠️ Como este projeto tem `wrangler.jsonc` com `pages_build_output_dir`, **o binding vem do arquivo, não do painel**. O `database_id` em `wrangler.jsonc` precisa ser o ID real gerado no passo 3 (o valor `00000000-...` não funciona). Faça commit dessa alteração antes do deploy.
   - Depois do deploy, confira em **Settings** → **Functions** → **D1 database bindings** se aparece `DB` → `db-p26-2b-1768-7598-7d8e-716e`, e acesse `/api/status`: deve mostrar `"d1Connected": true`.
5. **Configuração do Discord OAuth2 (Obrigatório para autenticação real):**
   - Acesse o **Discord Developer Portal** (https://discord.com/developers/applications) e crie uma nova Application.
   - Na aba **OAuth2**:
     - Copie o **Client ID** e gere o **Client Secret**.
     - Em **Redirects**, adicione a URL exata do deploy:
       `https://p26-2b-1768-7598-7d8e-716e.pages.dev/api/auth/discord/callback`
   - No painel do seu projeto no Cloudflare Pages:
     - Acesse **Settings** → **Environment variables**.
     - Adicione as variáveis de ambiente:
       - `DISCORD_CLIENT_ID`
       - `DISCORD_CLIENT_SECRET` *(marque como "Encrypt")*
       - `SESSION_SECRET` *(opcional, recomendado: um texto longo e aleatório para assinar a sessão; se ausente, usa o `DISCORD_CLIENT_SECRET`)*
   - Depois de salvar as variáveis, faça um novo deploy (**Deployments** → **Retry deployment**) para elas entrarem em vigor.
6. Atualize o campo **URL_CLOUDFLARE** no topo deste `README.md` com o endereço público gerado pela Cloudflare.
7. Na raiz do repositório, execute `node validar-local.mjs P26-2B-1768-7598-7D8E-716E` para validar todos os critérios antes de fazer o commit e abrir o Pull Request.
